"""Recheck archived paired differences using the original runner."""
import json
import math
from pathlib import Path
import os
import subprocess
import sys

here = Path(__file__).resolve().parent
manifest = json.loads((here / "manifest.json").read_bytes())
exe = str(Path(sys.argv[1]).resolve())
env = dict(os.environ, GOMAXPROCS="4")
for key in ("EASYBIS_NO_EFFECTS", "EASYBIS_ASSUMED_PPM"):
    env.pop(key, None)
for batch in manifest["batches"]:
    path = here / batch["input"]
    if len(sys.argv) > 2 and not path.name.startswith(sys.argv[2] + "."):
        continue
    result = subprocess.check_output([exe, str(path)], env=env,
        creationflags=getattr(subprocess, "BELOW_NORMAL_PRIORITY_CLASS", 0))
    expected = {x["key"]: x for x in json.loads((here / batch["output"]).read_bytes())}
    actual = json.loads(result)
    assert {x["key"] for x in actual} == set(expected)
    for row in actual:
        assert not row.get("error"), row
        for field in ("diff", "se", "dps", "Threat", "Incoming", "CatSeconds", "CatActivations"):
            assert math.isclose(row[field], expected[row["key"]][field], rel_tol=1e-10, abs_tol=1e-7), (path, row["key"], field)
    print(path.name, len(actual), flush=True)
