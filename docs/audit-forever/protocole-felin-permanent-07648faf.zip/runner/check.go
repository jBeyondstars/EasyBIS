// Two more commands of the driver, which _build/sim_specs.py and a check of a new spec use:
//
//	easybis_sim settings FILE.siml  the settings a SIML file of the checkout sets, with the files its use lines name, as JSON
//	easybis_sim check INPUT.json    what the simulator says of the first job's rotation, and what it casts in a short sim
package main

import (
	"encoding/json"
	"fmt"
	"os"

	"github.com/wowsims/forever/sim/core"
	"github.com/wowsims/forever/sim/core/proto"
	"github.com/wowsims/forever/sim/siml"
	"google.golang.org/protobuf/encoding/protojson"
)

func settings(path string) {
	f, err := siml.ReadFile(path)
	if err != nil {
		panic(err)
	}
	out, err := protojson.Marshal(f.Settings)
	if err != nil {
		panic(err)
	}
	os.Stdout.Write(out)
}

type checked struct {
	Dps         float64            `json:"dps"`
	SecondsOOM  float64            `json:"secondsOom"`
	Validations []string           `json:"validations"`
	Casts       map[string]float64 `json:"casts"` // per fight, by action, pets' actions after "pet "
	Stats       []float64          `json:"stats"` // the final stats
}

func validations(stats *proto.APLStats) []string {
	var out []string
	add := func(list []*proto.APLValidation) {
		for _, v := range list {
			out = append(out, fmt.Sprintf("%s: %s", v.LogLevel, v.Validation))
		}
	}
	for _, a := range stats.GetPrepullActions() {
		add(a.Validations)
	}
	for _, a := range stats.GetPriorityList() {
		add(a.Validations)
	}
	for _, u := range stats.GetUuidValidations() {
		add(u.Validations)
	}
	for _, g := range stats.GetGroups() {
		for _, a := range g.Actions {
			add(a.Validations)
		}
	}
	return out
}

func actionKey(id *proto.ActionID) string {
	key := ""
	switch raw := id.RawId.(type) {
	case *proto.ActionID_SpellId:
		key = fmt.Sprint("spell ", raw.SpellId)
	case *proto.ActionID_ItemId:
		key = fmt.Sprint("item ", raw.ItemId)
	case *proto.ActionID_OtherId:
		key = fmt.Sprint("other ", raw.OtherId)
	}
	if id.Tag != 0 {
		key += fmt.Sprint(" tag ", id.Tag)
	}
	return key
}

func casts(into map[string]float64, prefix string, actions []*proto.ActionMetrics, iterations float64) {
	for _, a := range actions {
		for _, t := range a.Targets {
			into[prefix+actionKey(a.Id)] += float64(t.Casts) / iterations
		}
	}
}

func check(base *proto.RaidSimRequest, in *input) {
	r := request(base, in, in.Jobs[0])
	out := checked{Casts: map[string]float64{}}
	cs := core.ComputeStats(&proto.ComputeStatsRequest{Raid: r.Raid, Encounter: r.Encounter})
	if cs.ErrorResult != "" {
		panic(cs.ErrorResult)
	}
	player := cs.RaidStats.Parties[0].Players[0]
	out.Validations = validations(player.RotationStats)
	out.Stats = player.FinalStats.GetStats()
	res := core.RunRaidSim(r)
	if res.Error != nil {
		panic(res.Error.Message)
	}
	metrics := res.RaidMetrics.Parties[0].Players[0]
	out.Dps, out.SecondsOOM = metrics.Dps.Avg, metrics.SecondsOomAvg
	casts(out.Casts, "", metrics.Actions, float64(in.Iterations))
	for _, pet := range metrics.Pets {
		casts(out.Casts, "pet ", pet.Actions, float64(in.Iterations))
	}
	json.NewEncoder(os.Stdout).Encode(out)
}
