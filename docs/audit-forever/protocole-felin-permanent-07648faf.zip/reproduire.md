# Reproduire la calibration de bijoux en forme de félin permanente

Les 20 fichiers de jobs classent les deux factions à 2 000 itérations par configuration, contre un boss de 180 ± 5 s, avec la même graine. Les deux emplacements de bijou sont vides dans chaque témoin. Le talent Shifting Power, les buffs et les affaiblissements de raid, les professions et les autres pièces sont ceux des fichiers. Les deux modes mesurent les statistiques permanentes, puis l’usage du bouton lorsqu’il est compatible avec la forme. Les champs ItemCasts, Inner, CatActivations, CatSeconds et DurationSeconds dans chaque sortie fournissent leurs contrôles.

La copie de feralcat.go ajoute une seule affectation au constructeur. Elle désactive la sortie automatique lors du lancement d’un sort incompatible. Les entrées retirent séparément Innervate et le retour en félin de l’APL. Les boutons 280065, 276337, 273643, 274152, 274641 et 284231 demandent une autre forme d’après les contraintes du client. Leurs lignes d’activation ne pressent pas ces boutons. Le diagnostic initial de 280065 montre pourquoi ce filtrage est nécessaire même quand la sortie automatique est désactivée.

Les 160 configurations passives et les 91 variantes d’utilisation individuelles donnent 251 lignes candidates. Les 40 autres lignes des sorties appariées sont leurs témoins vides et +40 PA. Le fichier de classement conserve les groupes de variantes de faction et emploie 1 point comme seuil d’admission des bijoux sans statistiques pondérées. Le dossier de sensibilité à la mana contient 24 000 combats complémentaires à 2 000 itérations par configuration.

Python 3 vérifie les empreintes de tous les fichiers depuis le dossier du ZIP, avec la commande suivante.

    python replay.py --verify-only

Pour refaire un lot, extraire les sources officielles de WoWSims Forever à la révision 07648faf129cd82f99f4dd9e63b015f59f8ec811 et installer Go. Les 17 protobuf générés sont fournis. Le pilote applique en mémoire de compilation la variante locale du constructeur et les protobuf, compare les résultats aux valeurs enregistrées et ne modifie pas les sources amont.

    python replay.py --upstream CHEMIN_WOWSIMS --job jobs/a-Leatherworking-00.json
    python replay.py --upstream CHEMIN_WOWSIMS --job sensibilite-mana/a-sans-Shifting-Power.input.json

Sans paramètre --job, les 20 lots principaux sont reproduits. Les fichiers dans comparaisons sont les paires et diagnostics complémentaires transmis par le responsable de l’audit. Les noms comportant original identifient des témoins avec Innervation. Ce dossier est conservé avec les entrées et sorties d’origine. Ces témoins n’entrent pas dans le classement sous verrou félin. La version de base de l’audit est exclue. Les résultats de sensibilité et les vérifications supplémentaires restent séparés des 291 configurations principales.
