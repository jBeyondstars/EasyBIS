from pathlib import Path
import argparse,hashlib,json,os,subprocess,tempfile
p=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description='Verify and replay the permanent Cat Form WoWSims 07648faf trials.')
parser.add_argument('--upstream',type=Path, help='Official WoWSims Forever 07648faf source checkout, with its assets')
parser.add_argument('--job',help='One input file under jobs/ or sensibilite-mana/ (default: all main trials).')
parser.add_argument('--verify-only',action='store_true')
args=parser.parse_args()
def digest(f):return hashlib.sha256(f.read_bytes()).hexdigest()
for name,expected in json.loads((p/'sha256.json').read_bytes()).items():
 assert digest(p/name)==expected,name
if args.verify_only:print('All packaged hashes verified.');raise SystemExit(0)
if not args.upstream:parser.error('--upstream is required for a replay')
up=args.upstream.resolve();di=json.loads((p/'diagnostic.json').read_bytes())
for name,expected in di['build_db_sha256'].items(): assert digest(up/'assets/database'/name)==expected,name
overlay={str(up/'sim/druid/feralcat/feralcat.go'):str(p/'feralcat.go')}
for f in (p/'generated-proto').glob('*.pb.go'):overlay[str(up/'sim/core/proto'/f.name)]=str(f)
low=getattr(subprocess,'BELOW_NORMAL_PRIORITY_CLASS',0);env={**os.environ,'CGO_ENABLED':'0','GOMAXPROCS':'3'}
with tempfile.TemporaryDirectory() as scratch:
 tmp=Path(scratch);exe=tmp/('runner.exe' if os.name=='nt' else 'runner');ov=tmp/'overlay.json';ov.write_text(json.dumps({'Replace':overlay}),encoding='utf8')
 subprocess.run(['go','build','-overlay',str(ov),'-tags=with_db','-o',str(exe),*[str(p/'runner'/name) for name in ['main.go','check.go','effects.go']]],cwd=up,env=env,check=True,creationflags=low)
 inputs=[p/args.job] if args.job else sorted((p/'jobs').glob('*.json'))
 for src in inputs:
  if src.parent.name not in ('jobs','sensibilite-mana'):raise ValueError('Use a ranked or a mana sensitivity case')
  expected=p/'results'/src.name if src.parent.name=='jobs' else src.with_name(src.name.replace('.input.json','.json'))
  rows=json.loads(subprocess.check_output([str(exe),str(src)],cwd=up,env=env,creationflags=low))
  old=json.loads(expected.read_bytes());assert len(rows)==len(old)
  for a,b in zip(rows,old):
   assert a['key']==b['key'] and a.get('error')==b.get('error')
   for k in ['dps','se','diff','CounterpartSE','CatSeconds','DurationSeconds','CatActivations','Inner','Power']:
    assert abs(a[k]-b[k])<1e-7,(src,a['key'],k,a[k],b[k])
   assert a['ItemCasts']==b['ItemCasts']
  print(src.name,len(rows),'OK',flush=True)
