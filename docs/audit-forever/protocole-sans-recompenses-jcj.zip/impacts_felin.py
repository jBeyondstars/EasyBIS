from pathlib import Path
import json,os,sys
p=Path(__file__).parent;root=Path.cwd();sys.path.insert(0,str(root/'_build'));import fdb,ladders,feral_gear
db=fdb.load(root/'_build/cache/ForeverDB');d=p/'sans-jcj';g=p/'anneau-felin'
def save(f,x):f.write_text(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf8')
def inventory(sources):
 feral_gear.FILES=sources;feral_gear._read.cache_clear();feral_gear._ranking.cache_clear()
 ret={}
 for sl in ('off','trinket'):
  pool=ladders.full_ladder(db,'DRUID',4,'pve',sl);ret[sl]={}
  kept=ladders.kept_ladder(sl,pool)
  for f in ladders.FILTERS:
   vis=ladders.visible(kept,f);best,alt=ladders.picks(sl,vis,6)
   ret[sl]['/'.join(str(v) for v in f)]=[[e.shown(f[0]) for e in group] for group in (best,alt)]
 return ret
def src(root,prefix):return {sl:root/(prefix+'feral_'+fname+'.json') for sl,fname in [('off','offhands'),('trinket','trinkets')]}
data={'alternatives_demandées':6,'filters':['faction','allow_unknown_sources','seen_only','phase','include_pvp_rewards','max_honor_rank'],'contexts_per_slot':len(ladders.FILTERS)}
base=inventory(src(g,''));gr=inventory(src(g,'updated-'));main=inventory(src(d,'updated-'))
for label,old in [('première_calibration',base),('Blackstone_avec_récompenses',gr)]:
 diff={}
 for sl,cases in main.items():
  heads=0;any_change=0;changes={}
  for flt,now in cases.items():
   before=old[sl][flt]
   if now==before:continue
   any_change+=1;heads+=int(now[0]!=before[0]);changes[flt]=[before,now]
  diff[sl]={'filtres_premiers_choix_différents':heads,'filtres_affichage_différent':any_change,'avant_après':changes}
 data[label]=diff
save(d/'impact-filtres.json',data)
print(len(ladders.FILTERS),{context:{s:(r['filtres_premiers_choix_différents'],r['filtres_affichage_différent']) for s,r in diff.items()} for context,diff in data.items() if isinstance(diff,dict)})

