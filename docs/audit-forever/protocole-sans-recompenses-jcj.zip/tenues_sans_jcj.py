from copy import deepcopy
# Positions use the engine's 17-slot ordering. All replacements have non-PvP acquisition for both factions.
REPLACEMENTS = {
    "cat": {5: {19587: 18375}, 10: {19325: 272408}, 11: {275981: 17713}, 14: {19323: 18420}},
    "bear": {8: {22749: 11821, 22740: 11821}, 10: {19325: 15855}, 12: {17904: 272440, 17909: 272440}, 14: {19323: 18531}},
    "war": {11: {19325: 272409}, 15: {19321: 12602}},
    "pal": {},
}
def transform(f,gear):
    out=list(gear)
    for slot,changes in REPLACEMENTS[f].items():out[slot]=changes.get(gear[slot],gear[slot])
    return out

def transform_config(cfg,role):
    cfg=deepcopy(cfg)
    for j in cfg['jobs']:
        before=[row['id'] for row in j['gear']];after=transform(role,before)
        for slot,ii in enumerate(after):
            if ii==before[slot]:continue
            if role=='war' and slot==15:
                bonus=j.setdefault('Bonus',{});assert bonus.get('24',0)==-13,(j['key'],bonus)
                bonus.pop('24')
                if not bonus:j.pop('Bonus')
            j['gear'][slot]['id']=ii
        for i in (10,12):assert after[i]==0 or after[i]!=after[i+1],(role,j['key'],after)
    return cfg

