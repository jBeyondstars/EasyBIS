from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import ctypes,os,subprocess,json,sys
from tenues_sans_jcj import transform_config
if os.name=='nt':ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(),0x4000)
p=Path(__file__).resolve().parent;t=p.parent;old=t/'easybis-3289-four-profiles';off=t/'easybis-cat-off-audit';dst=p/'sans-jcj';dst.mkdir(exist_ok=True);mana=p/'anneau-felin/runner-mana/runner.exe'
def ld(path):return json.loads(path.read_bytes())
def save(path,x):path.write_text(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf8')
work=[]
def add(path,k,priority=4,profile='cat',engine=None):
    work.append((priority,profile,k,path,engine or old/'runner.exe'))
for ip in sorted((old/'calibration-checks').glob('cat-*.input.json')):
    high=any(x in ip.name for x in ('heart-50000','trinket-ap-20000','hands-20000','bones-20000'));add(ip,'bijoux',0 if high else (1 if 'qualified-' in ip.name else 4))
for part in ('pool-5000','pool-20000','pool-20000-second',''):
    for ip in sorted((off/part).glob('*.input.json')):add(ip,'main-gauche/'+(part or 'direct'),0 if (not part and any(x in ip.name for x in ('persuader','heartseeker'))) else 3 if part=='pool-5000' else 2)
for s in 'ah':
    add(old/'groups'/f'direct-cat-{s}-off.input.json','grace',0)
    add(off/f'utility-{s}.input.json','medicine',1,engine=mana)
    for f in ('cat','bear'):add(p/'feral-form-controls'/f'{f}-{s}.input.json','form',1,f)
def run(z):
    pr,role,area,ip,bin=z;folder=dst/area;folder.mkdir(parents=True,exist_ok=True);cfg=transform_config(ld(ip),role)
    dest=folder/ip.name;out=dest.with_name(ip.name.replace('.input.json','.json'));save(dest,cfg)
    if out.is_file():return
    res=json.loads(subprocess.run(creationflags=getattr(subprocess,"BELOW_NORMAL_PRIORITY_CLASS",0),args=[str(bin),str(dest)],env={**os.environ,'GOMAXPROCS':'3'},check=True,capture_output=True).stdout)
    assert [j['key'] for j in cfg['jobs']]==[r['key'] for r in res] and not any(r.get('error') for r in res)
    save(out,res);print(role,area,ip.name,len(res),flush=True)
    if area=='medicine':
        test={**cfg,'iterations':10,'jobs':[cfg['jobs'][-1]]};check=folder/('check-'+ip.name.split('-')[1][0]+'.json');save(check,test);trace=json.loads(subprocess.run(creationflags=getattr(subprocess,"BELOW_NORMAL_PRIORITY_CLASS",0),args=[str(bin),'check',str(check)],check=True,capture_output=True).stdout);assert trace['casts'].get('item 15866',0)>0;save(folder/('trace-'+ip.name.split('-')[1][0]+'.json'),trace)
work.sort(key=lambda x:(x[0],x[2],x[3].name))
with ThreadPoolExecutor(max_workers=5) as ex:list(ex.map(run,work))
print('Done',len(work),flush=True)

