# Rejeu sans récompenses JcJ
Les entrées et les sorties conservent les deux factions, la graine, la tenue et chaque témoin. Dans les sorties standard, la métrique diff est le DPS supplémentaire contre le témoin. Dans les sorties de tanks, le JSON comparaison donne les différences de menace et de dégâts reçus avec erreurs standard appariées.

Les trois Go du répertoire runner composent le pilote standard, avec le tag with_db sur le checkout WoWSims indiqué dans comparaison.json et les protobuf Go de ce projet. Ajouter veildust.go uniquement pour les deux groupes medicine. Les contrôles de bijoux de tank nécessitent le pilote séparé tank-probe. Depuis le checkout WoWSims, au format PowerShell (remplacer $p par le chemin d’extraction) :

```powershell
$env:CGO_ENABLED = '0'
$env:GOARCH = 'amd64'
go build -tags=with_db -o "$p/runner.exe" "$p/runner/main.go" "$p/runner/check.go" "$p/runner/effects.go"
& "$p/runner.exe" "$p/grace/direct-cat-a-off.input.json"
python "$p/tank-probe/instrument_overlay.py" . "$p/overlay"
go build -tags=with_db -overlay "$p/overlay/overlay.json" -o "$p/tank.exe" "$p/tank-probe/main.go" "$p/tank-probe/check.go" "$p/tank-probe/effects.go"
& "$p/tank.exe" "$p/tanks-instrumentes/tank-bear-a-physical-20000.input.json"
```

Le script verify_sans.py vérifie les fichiers extraits, recompile les pilotes félin normal, sac de médecine et tank instrumenté, et reproduit les trois groupes repères. SHA256SUMS.json contient toutes les empreintes. Les répétitions félin avec récompenses de champ de bataille figurent dans protocole-calibration-felin-anneau.zip. Les boucliers sont rejoués à graine commune dans les deux contextes. Les bijoux des tanks sont mesurés avec le pilote qui enregistre les auras, l’absorption et les blocages.
