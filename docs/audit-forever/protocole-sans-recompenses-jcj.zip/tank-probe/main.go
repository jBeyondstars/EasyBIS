// The driver _build/simulate.py runs: it sims gear sets with WoWSims Forever (https://github.com/wowsims/forever,
// MIT License), each against the first one with the same random seed, and prints the paired difference.
//
// It is built inside a checkout of WoWSims, which it imports, and is no part of the addon:
//
//	easybis_sim INPUT.json        INPUT: {base (a RaidSimRequest), iterations, seed, duration, jobs: [{key, gear, onUse}]}
//	easybis_sim effects IDS.json  which of those items have an effect the simulator implements
//
// and the two commands of check.go.
package main

import (
	"encoding/json"
	"fmt"
	"math"
	"os"
	"runtime"
	"slices"
	"sync"

	"github.com/wowsims/forever/sim"
	"github.com/wowsims/forever/sim/core"
	"github.com/wowsims/forever/sim/core/proto"
	"github.com/wowsims/forever/sim/core/stats"
	"google.golang.org/protobuf/encoding/protojson"
	googleProto "google.golang.org/protobuf/proto"
)

type piece struct {
	ID      int32 `json:"id"`
	Enchant int32 `json:"enchant"`
}
type job struct {
 Bonus map[int]float64
 RefKey string
	Key   string  `json:"key"`
	Gear  []piece `json:"gear"`
	OnUse []int32 `json:"onUse"`
}
type input struct {
 Swing float64
School int32
City bool

	Base       json.RawMessage `json:"base"`
	Iterations int32           `json:"iterations"`
	Seed       int64           `json:"seed"`
	Duration   float64         `json:"duration"`
	Jobs       []job           `json:"jobs"`
}
type output struct {
 Absorb float64
 Blocked float64
 DeathRate float64
 Aura map[int32][]float64
 Duration float64

 ThreatSE float64
 IncomingSE float64
 Threat float64
 Incoming float64
 TMI float64
	Key   string  `json:"key"`
	Dps   float64 `json:"dps"`
	Stdev float64 `json:"stdev"`
	Diff  float64 `json:"diff"`
	SE    float64 `json:"se"`
	Error string  `json:"error,omitempty"`
}

// The stone a weapon takes, as the simulator's own batch sim chooses it.
func imbue(id int32, weapon *proto.ItemSpec) int32 {
	if id != core.DenseSharpeningStoneID && id != core.DenseWeightstoneID {
		return id
	}
	item := core.GetItemByID(weapon.Id)
	if item == nil {
		return 0
	}
	if slices.Contains(core.SharpWeaponTypes, item.WeaponType) {
		return core.DenseSharpeningStoneID
	}
	if slices.Contains(core.BluntWeaponTypes, item.WeaponType) {
		return core.DenseWeightstoneID
	}
	return 0
}

func request(base *proto.RaidSimRequest, in *input, j job) *proto.RaidSimRequest {
	r := googleProto.Clone(base).(*proto.RaidSimRequest)
	p := r.Raid.Parties[0].Players[0]
	items := make([]*proto.ItemSpec, len(j.Gear))
	for i, g := range j.Gear {
		items[i] = &proto.ItemSpec{Id: g.ID, Enchant: g.Enchant}
	}
	p.Equipment = &proto.EquipmentSpec{Items: items}
 if len(j.Bonus)>0 { if p.BonusStats==nil {p.BonusStats=&proto.UnitStats{}}; for stat, v := range j.Bonus {for len(p.BonusStats.Stats)<=stat {p.BonusStats.Stats=append(p.BonusStats.Stats,0)}; p.BonusStats.Stats[stat]+=v} }
	main, off := items[proto.ItemSlot_ItemSlotMainHand], items[proto.ItemSlot_ItemSlotOffHand]
	if main.Id == 0 {
		p.Consumables.MhImbueId, p.Consumables.MhWeaponImbueId = 0, 0
	} else {
		p.Consumables.MhImbueId = imbue(p.Consumables.MhImbueId, main)
	}
	if off.Id == 0 {
		p.Consumables.OhImbueId, p.Consumables.OhWeaponImbueId = 0, 0
	} else {
		p.Consumables.OhImbueId = imbue(p.Consumables.OhImbueId, off)
	}
	// An on-use item only fires when the rotation has an action for it.
	var uses []*proto.APLListItem
	for _, id := range j.OnUse {
		uses = append(uses, &proto.APLListItem{Action: &proto.APLAction{Action: &proto.APLAction_CastSpell{
			CastSpell: &proto.APLActionCastSpell{SpellId: &proto.ActionID{RawId: &proto.ActionID_ItemId{ItemId: id}}},
		}}})
	}
	placed := false
	for _, group := range p.Rotation.Groups {
		if group.Name == "CD: Trinkets" {
			group.Actions = append(group.Actions, uses...)
			placed = true
		}
	}
	if !placed {
		p.Rotation.PriorityList = append(uses, p.Rotation.PriorityList...)
	}
	target := core.FreshDefaultTargetConfig()
	if p.InFrontOfTarget { target.MinBaseDamage = 2601; target.SwingSpeed = 2; target.TankIndex = 0; target.CanCrush = true; target.ParryHaste = true }
 if in.Swing>0 { target.SwingSpeed=in.Swing }; target.SpellSchool=proto.SpellSchool(in.School)
 target.Id, target.Name = 31146, "Raid Target"
	target.Stats[stats.Health] = 1428900
	target.Stats[stats.BlockValue] = 54
	r.Encounter = &proto.Encounter{Duration: in.Duration, DurationVariation: 5, ExecuteProportion_20: 0.2,
		ExecuteProportion_35: 0.35, Targets: []*proto.Target{target}}
	if in.City {r.Encounter.AreaTypes=[]proto.AreaType{proto.AreaType_AreaTypeStrongholdsCities}}
 r.SimOptions = &proto.SimOptions{Iterations: in.Iterations, RandomSeed: in.Seed, SaveAllValues: true}
	r.Type = proto.SimType_SimTypeIndividual
	return r
}

func run(base *proto.RaidSimRequest, in *input, j job) (res *proto.RaidSimResult, msg string) {
	defer func() {
		if e := recover(); e != nil {
			msg = fmt.Sprint(e)
		}
	}()
	res = core.RunRaidSim(request(base, in, j))
	if res.Error != nil {
		return nil, res.Error.Message
	}
	return res, ""
}

func effects(path string) {
	var ids []int32
	data, err := os.ReadFile(path)
	if err != nil {
		panic(err)
	}
	if err := json.Unmarshal(data, &ids); err != nil {
		panic(err)
	}
	out := map[string]bool{}
	for _, id := range ids {
		out[fmt.Sprint(id)] = core.HasItemEffect(id)
	}
	json.NewEncoder(os.Stdout).Encode(out)
}

func main() {
	sim.RegisterAll()
	registerEffects()
	if len(os.Args) == 3 && os.Args[1] == "effects" {
		effects(os.Args[2])
		return
	}
	if len(os.Args) == 3 && os.Args[1] == "settings" {
		settings(os.Args[2])
		return
	}
	data, err := os.ReadFile(os.Args[len(os.Args)-1])
	if err != nil {
		panic(err)
	}
	var in input
	if err := json.Unmarshal(data, &in); err != nil {
		panic(err)
	}
	base := &proto.RaidSimRequest{}
	if err := protojson.Unmarshal(in.Base, base); err != nil {
		panic(err)
	}
	if len(os.Args) == 3 && os.Args[1] == "check" {
		check(base, &in)
		return
	}
	// Every set runs in the pool, the reference among them: run alone first, it held one core while the others waited.
	results := make([]output, len(in.Jobs))
	values := make([][]float64, len(in.Jobs))
 threats := make([][]float64, len(in.Jobs))
 incoming := make([][]float64, len(in.Jobs))
	queue := make(chan int, len(in.Jobs))
	for i := range in.Jobs {
		queue <- i
	}
	close(queue)
	var wg sync.WaitGroup
	for range runtime.NumCPU() {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for i := range queue {
				o := output{Key: in.Jobs[i].Key}
				res, msg := run(base, &in, in.Jobs[i])
				if msg != "" {
					o.Error = msg
				} else {
					u := res.RaidMetrics.Parties[0].Players[0]
 for _, a := range u.Actions {if a.Id.GetItemId()==19024 {for _,t:=range a.Targets{o.Absorb+=t.Shielding/float64(in.Iterations)}}}
 for _, a:=range res.EncounterMetrics.Targets[0].Actions {for _,t:=range a.Targets {o.Blocked+=float64(t.Blocks+t.BlockedCrits+t.GlanceBlocks)/float64(in.Iterations)}}
 o.DeathRate=u.ChanceOfDeath;o.Duration=res.AvgIterationDuration;o.Aura=map[int32][]float64{}
 for _, aura:=range u.Auras {id:=aura.Id.GetSpellId();if id==0 {id=-aura.Id.GetItemId()}; if id==0{continue};o.Aura[id]=[]float64{aura.UptimeSecondsAvg,aura.UptimeSecondsStdev,aura.ProcsAvg}}
 o.Threat, o.Incoming, o.TMI = u.Threat.GetAvg(), u.Dtps.GetAvg(), u.Tmi.GetAvg()
 threats[i], incoming[i] = u.Threat.AllValues, u.Dtps.AllValues
 d := res.RaidMetrics.Dps
					o.Dps, o.Stdev = d.Avg, d.Stdev
					values[i] = d.AllValues
				}
				results[i] = o
			}
		}()
	}
	wg.Wait()
	if results[0].Error != "" {
		panic("reference: " + results[0].Error)
	}
	index := map[string]int{}; for i, j := range in.Jobs {index[j.Key]=i}
	for i := range results {
		refidx := index[in.Jobs[i].RefKey]
 ref := values[refidx]
 if values[i] == nil || ref == nil {
			continue
		}
		var sum, sq float64
		for k, v := range values[i] {
			x := v - ref[k]
			sum += x
			sq += x * x
		}
		n := float64(len(ref))
		results[i].ThreatSE = pairedError(threats[i], threats[refidx])
 results[i].IncomingSE = pairedError(incoming[i], incoming[refidx])
 results[i].Diff = sum / n
		results[i].SE = math.Sqrt(math.Max(sq/n-results[i].Diff*results[i].Diff, 0) / n)
	}
	json.NewEncoder(os.Stdout).Encode(results)
}

func pairedError(values, ref []float64) float64 {
 if len(values) == 0 || len(ref) != len(values) { return 0 }
 var sum, square float64
 for k, v := range values { d := v-ref[k]; sum += d; square += d*d }
 n := float64(len(ref))
 return math.Sqrt(math.Max(square/n-(sum/n)*(sum/n),0)/n)
}
