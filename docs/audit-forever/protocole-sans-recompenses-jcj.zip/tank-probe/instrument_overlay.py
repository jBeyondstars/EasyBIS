from pathlib import Path
import json,sys
root=Path(sys.argv[1]).resolve();d=Path(sys.argv[2]).resolve();d.mkdir(exist_ok=True,parents=True)
src=root/'sim/common/shared/shared_utils.go';raw=src.read_text(encoding='utf8')
key='\tif id, ok := AbsorbBreakDamage(absorb); ok {'
assert raw.count(key)==1
hook=''' if sourceID == 19024 {
  shield.AttachOnDamageAbsorbed(func(_ *core.Simulation, _ *core.DamageAbsorptionAura, _ *core.SpellResult, amount float64) {
   tracker := character.GetSpell(core.ActionID{ItemID: sourceID})
   if tracker == nil { panic("missing item-use action") }
   tracker.SpellMetrics[character.UnitIndex].TotalShielding += amount
  })
 }
'''
replacement=d/'shared_utils.go';replacement.write_text(raw.replace(key,hook+key),encoding='utf8')
(d/'overlay.json').write_text(json.dumps({'Replace':{str(src):str(replacement)}}),encoding='utf8')

