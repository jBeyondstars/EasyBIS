from pathlib import Path
import os,sys,json,copy,subprocess,ctypes
from concurrent.futures import ThreadPoolExecutor
from tenues_sans_jcj import transform_config
if os.name=='nt':ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(),0x4000)
p=Path(__file__).resolve().parent;old=p.parent/'easybis-3289-four-profiles';dst=p/'sans-jcj';root=Path.cwd()
def ld(f):return json.loads(f.read_bytes())
def save(f,j):f.write_text(json.dumps(j,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf8')
tasks=[]
for fi in sorted((old/'calibration-checks').glob('tank-*.input.json')):
 f=fi.name.split('-')[1]
 if any(c in fi.name for c in ('sustain','pair0','pair45','physical','grip-calibration')):tasks.append((fi,f,'sans-jcj','tanks-instrumentes',True))
for f in ('pal','war'):
 for side in 'ah':
  ip=old/'groups'/f'direct-{f}-{side}-shields.input.json'
  for mode in ('grade6','sans-jcj'):tasks.append((ip,f,mode,'boucliers',False))
def run(task):
 ip,role,mode,category,instr=task;d=dst/category;d.mkdir(exist_ok=True);cfg=ld(ip)
 if mode=='sans-jcj':cfg=transform_config(cfg,role)
 if not instr:
  cfg['iterations']=20000;cfg['seed']=713829
  extra=copy.deepcopy(cfg['jobs'][0]);extra['key']='18696';extra['gear'][15]['id']=18696
  fix=ld(old/'engine-meta.json')['shield_corrections'].get('18696',{}).get('delta',0)
  if fix:extra['Bonus']={'24':fix}
  cfg['jobs'].append(extra)
 ident=ip.name if instr else mode+'_'+ip.name;target=d/ident;save(target,cfg)
 o=target.with_name(target.name.replace('.input.json','.json'))
 if o.exists():return
 engine=(old/'tank-probe' if instr else old)/'runner.exe'
 z=json.loads(subprocess.run(creationflags=getattr(subprocess,"BELOW_NORMAL_PRIORITY_CLASS",0),args=[str(engine),str(target)],env={**os.environ,'GOMAXPROCS':'3'},capture_output=True,check=True).stdout)
 assert [j['key'] for j in cfg['jobs']]==[r['key'] for r in z] and all(not r.get('error') for r in z)
 if instr:assert all('Aura' in r and 'Blocked' in r for r in z)
 save(o,z);print(ident,len(z),flush=True)
tasks.sort(key=lambda q:(0 if q[3]=='boucliers' or 'physical' in q[0].name else 1 if 'sustain' in q[0].name else 2,q[0].name))
with ThreadPoolExecutor(max_workers=3) as e:list(e.map(run,tasks))
print('Done',len(tasks))

