from pathlib import Path
import json,hashlib,os,subprocess,sys,tempfile,ctypes
from zipfile import ZipFile
if os.name=='nt':ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(),0x4000)
package,checkout=map(Path,sys.argv[1:]);env={**os.environ,'CGO_ENABLED':'0','GOARCH':'amd64','GOMAXPROCS':'4'}
def js(f):return json.loads(f.read_bytes())
with tempfile.TemporaryDirectory(prefix='easybis-ring-') as temp:
    out=Path(temp)
    with ZipFile(package) as z:
        assert z.testzip() is None
        z.extractall(out)
    fingerprints=js(out/'SHA256SUMS.json')
    for name,digest in fingerprints.items():assert hashlib.sha256((out/name).read_bytes()).hexdigest()==digest,name
    sources=[str(out/'runner'/n) for n in ('main.go','check.go','effects.go')]
    for prefix,group,extra in [('grace','direct-cat-a-off',[]),('medicine','utility-a',[str(out/'runner/veildust.go')])]:
        ran=out/('test-'+prefix+'.exe')
        subprocess.run(creationflags=getattr(subprocess,"BELOW_NORMAL_PRIORITY_CLASS",0),args=['go','build','-tags=with_db','-o',str(ran),*sources,*extra],cwd=checkout,env=env,check=True)
        ip=out/prefix/(group+'.input.json');res=json.loads(subprocess.run(creationflags=getattr(subprocess,"BELOW_NORMAL_PRIORITY_CLASS",0),args=[str(ran),str(ip)],env=env,check=True,capture_output=True).stdout)
        expected=js(out/prefix/(group+'.json'));assert {r['key'] for r in res}=={r['key'] for r in expected}
        for r,e in zip(res,expected):
            for k in ('key','dps','diff','se','Threat','Incoming'):
                if k=='key':assert r[k]==e[k]
                else:assert abs(r[k]-e[k])<1e-8,(r['key'],k,r[k],e[k])
        print(prefix,len(res),'résultats reproduits',flush=True)
    overlay=out/'overlay';probe=out/'tank.exe'
    subprocess.run([sys.executable,str(out/'tank-probe/instrument_overlay.py'),str(checkout),str(overlay)],check=True,env=env,creationflags=getattr(subprocess,'BELOW_NORMAL_PRIORITY_CLASS',0))
    files=[str(out/'tank-probe'/label) for label in ('main.go','check.go','effects.go')]
    subprocess.run(['go','build','-tags=with_db','-overlay',str(overlay/'overlay.json'),'-o',str(probe),*files],cwd=checkout,check=True,env=env,creationflags=getattr(subprocess,'BELOW_NORMAL_PRIORITY_CLASS',0))
    fi=out/'tanks-instrumentes/tank-bear-a-physical-20000.input.json'
    results=json.loads(subprocess.run([str(probe),str(fi)],check=True,env=env,capture_output=True,creationflags=getattr(subprocess,'BELOW_NORMAL_PRIORITY_CLASS',0)).stdout)
    expected=js(fi.with_name(fi.name.replace('.input.json','.json')))
    assert len(results)==len(expected)
    for actual,record in zip(results,expected):
        assert actual['key']==record['key']
        for metric in ('dps','Threat','Incoming','ThreatSE','IncomingSE','Blocked','Absorb','Aura'):
            assert actual[metric]==record[metric],(actual['key'],metric)
    print('tanks',len(results),'résultats et auras reproduits',flush=True)
    print('SHA-256 vérifiés',len(fingerprints),flush=True)

