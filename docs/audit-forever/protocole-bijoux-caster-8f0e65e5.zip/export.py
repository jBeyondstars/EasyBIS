from collections import Counter
from grid_pairs import *
from checkpairs import scan
from datetime import date
def export():
 out={'wowsims':'8f0e65e5429423a40cca10632af9585b0d9938f2','engine_sha256':BIN,'iterations':2000,'seed':388241,'duration_seconds':180,'duration_variation_seconds':5,'scope':'Pre-raid PvE, neutral level-63 boss, no struck-by-fire or marsh bonus. Both trinkets empty for the first gain; for a partner, its exact item stays equipped. Other slots, race, rotation and other cooldowns stay fixed. On-use actions ordered by ascending item ID.','columns':['gain_dps','paired_se','iterations','model'],'profiles':{}}
 checks={};missing=[]
 for k,es in RAW.items():
  c,n,side=k;profile=f'{c} {n}';case=f'{c}-{n}-{side}';pref=out['profiles'].setdefault(profile,{'contexts':{},'references':{}})
  table=read(P/'tables'/f'{case}-0.json')
  a,filters=rank(k);keys=sorted({int(r[0])for r in filters.values()})
  needed=[0,*keys]
  for i in needed:
   fn=P/'tables'/f'{case}-{i}.json'
   if not fn.exists():missing.append(str(fn));continue
   rr=read(fn)
   filtered={str(i):rr[str(i)]for i,e in sorted(es.items())if e.phase==0 and str(i) in rr}
   # A listed trinket can be unavailable on this faction or incompatible with its equipped companion.
   if not i:assert {'13968','12930'}<=set(filtered)
   ctx=side if not i else f'{side}:{i}';pref['contexts'][ctx]=filtered
  j=read(P/'jobs'/f'{case}-0.json');ref=j['jobs'][0];pl=j['base']['raid']['parties'][0]['players'][0];pref['references'][side]={'race':pl['race'],'gear':ref['gear'],'rotation_request_sha256':hashlib.sha256(json.dumps(j['base'],sort_keys=True,separators=(',',':')).encode()).hexdigest(),'solo_input_sha256':sha(P/'jobs'/f'{case}-0.json')}
  res=scan(k);doubles=read(P/'doubles'/f'{case}-0.out.json')['rows'][-1]
  for z in res.values():
   z['22268_double_dps']=doubles['dps'];z['22268_caveat']='One proc registration for both copies; actual stacking in game unknown.'
  checks[profile+' '+side]=res
 if missing:
  print('missing',len(missing),[Path(f).name for f in missing]);return
 final=P/'delivery';final.mkdir(exist_ok=True);write(final/'verification.json',checks)
 dest=final/'caster_trinkets.json'
 # One context per line so diffs show which partner changed.
 text=json.dumps(out,sort_keys=True,indent=1,ensure_ascii=False)
 import re
 text=re.sub(r'\[\s*(null|-?[\d.eE+\-]+),\s*(null|[\d.eE+\-]+),\s*(\d+),\s*"([a-z_]+)"\s*\]',r'[\1, \2, \3, "\4"]',text)
 dest.write_text(text+'\n','utf8')
 print('READY',len(out['profiles']),sum(len(z['contexts']) for z in out['profiles'].values()),sha(dest))
if __name__=='__main__':export()
