from grid import *
from copy import deepcopy
def double(k):
 c,n,side=k
 if 22268 not in RAW[k]:return
 tag=f'{c}-{n}-{side}-0';q=read(P/'jobs'/f'{tag}.json');j=deepcopy(next(j for j in q['jobs']if j['key']=='22268'));j['gear'][13]={'id':22268,'enchant':0};j['key']='22268x2';q['jobs']=[q['jobs'][0],j];fn=P/'doubles'/f'{tag}.json';write(fn,q);r=subprocess.run([str(EXE),str(fn)],capture_output=True,env={**os.environ,'GOMAXPROCS':'2'},creationflags=getattr(subprocess,'BELOW_NORMAL_PRIORITY_CLASS',0));assert not r.returncode,(tag,r.stderr);rows=json.loads(r.stdout);assert not any(x.get('error')for x in rows);write(fn.with_suffix('.out.json'),{'engine':BIN,'input':sha(fn),'rows':rows})
if __name__=='__main__':
 (P/'doubles').mkdir(exist_ok=True)
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(double,RAW))
