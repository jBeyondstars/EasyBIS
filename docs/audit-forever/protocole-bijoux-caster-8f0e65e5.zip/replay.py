"""Replay a stored input against the patched WoWSims checkout and compare all recorded DPS and SE."""
import argparse, hashlib, json, os, pathlib, subprocess, tempfile
p=argparse.ArgumentParser();p.add_argument('checkout',type=pathlib.Path);p.add_argument('input',type=pathlib.Path);p.add_argument('result',type=pathlib.Path);a=p.parse_args()
root=pathlib.Path(__file__).resolve().parent
expected=json.loads(a.result.read_bytes())
assert hashlib.sha256(a.input.read_bytes()).hexdigest()==expected['input']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=a.checkout,text=True).strip()=='8f0e65e5429423a40cca10632af9585b0d9938f2'
with tempfile.TemporaryDirectory() as tmp:
 temp=pathlib.Path(tmp);exe=temp/('replay.exe'if os.name=='nt'else 'replay');ov=temp/'overlay.json'
 target=(a.checkout/'sim/common/forever/stat_bonus_cds_auto_gen.go').resolve()
 ov.write_text(json.dumps({'Replace':{str(target):str((root/'driver/trinkets.go').resolve())}}))
 subprocess.run(['go','build','-tags=with_db','-overlay',str(ov),'-o',str(exe),*(str(root/'driver'/n)for n in ('main.go','check.go','effects.go'))],cwd=a.checkout,env={**os.environ,'GOARCH':'amd64','CGO_ENABLED':'0'},check=True)
 got=json.loads(subprocess.check_output([str(exe),str(a.input.resolve())],env={**os.environ,'GOMAXPROCS':'4'}))
 assert len(got)==len(expected['rows'])
 for row,orig in zip(got,expected['rows']):
  assert row['key']==orig['key']
  assert not row.get('error')
  for k in ('dps','diff','se'):
   assert abs(row[k]-orig[k])<1e-6,(row['key'],k,row[k],orig[k])
 print('Matched',len(got),'gear configurations.')
