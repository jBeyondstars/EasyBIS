from grid_pairs import *
if __name__=='__main__':
 tasks=[]
 for k in RAW:
  c,n,s=k
  if c not in ('WARLOCK',) or n<2:continue
  a,f=rank(k);top=set()
  for r in f.values():top.update(r[:3])
  top.update(f[str((s,False,False,0,False,5))][:5])
  tasks.extend((*k,i) for i in sorted(top) if not (P/'tables'/('-'.join(map(str,(*k,i)))+'.json')).exists())
 print('remaining',tasks,flush=True);run(tasks)
