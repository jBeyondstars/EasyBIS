from grid_pairs import *
from itertools import combinations
def relic(k):
 c,n,s=k;tag=f'{c}-{n}-{s}';p=P/'relic-comparison';p.mkdir(exist_ok=True);rr=rank(k)[1];R={z[0] for z in rr.values()}
 eligible=RAW[k];A={13968,12930,272438};A.update(R);ids=set().union(*(x[:4] for x in rr.values()))
 # Test the strongest normal pre-raid candidates and all possible first picks across the broader filter settings.
 q=read(P/'jobs'/f'{tag}-0.json');ref=q['jobs'][0]
 def pack(items):
  j=copy.deepcopy(ref);j['key']='+'.join(map(str,items)) if items else 'empty'
  j['gear'][16]={'id':{'DRUID':272430,'SHAMAN':23199,'PALADIN':23203}[c],'enchant':0}
  for idx in range(2):j['gear'][12+idx]={'id':items[idx] if idx<len(items) else 0,'enchant':0}
  j['onUse']=sorted(set(j.get('onUse',[]))|{id for id in items if id not in(20036,4696) and any(e.get('onUse')for e in D[id].get('itemEffects',[]))});return j
 test={(i,)for i in ids|A};test.update(tuple(sorted((i,j)))for i,j in combinations(ids|A,2) if compatible(i,j) and (i in A or j in A))
 q['jobs']=[pack(())]+[pack(z)for z in sorted(test)];ip=p/f'{tag}.json';write(ip,q);raw=subprocess.run([str(EXE),str(ip)],capture_output=True,env={**os.environ,'GOMAXPROCS':'4'},creationflags=getattr(subprocess,'BELOW_NORMAL_PRIORITY_CLASS',0));assert not raw.returncode,raw.stderr;rows=json.loads(raw.stdout);assert not any(r.get('error')for r in rows);write(ip.with_suffix('.out.json'),{'engine':BIN,'input':sha(ip),'rows':rows});print(k,len(rows),flush=True)
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=4)as ex:list(ex.map(relic,[k for k in RAW if k[0]in ('DRUID','SHAMAN','PALADIN')]))
