from pathlib import Path
import json,os,hashlib,re,tempfile
p=Path(__file__).resolve().parent;t=p/'relic-grid';d=p/'delivery';read=lambda f:json.loads(f.read_bytes());h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
if __name__=='__main__':
 a=read(d/'caster_trinkets.json');r=read(t/'delivery/caster_trinkets.json');assert a['engine_sha256']==r['engine_sha256']
 a['profiles'].update(r['profiles'])
 for c,rel in (('DRUID 1',272430),('SHAMAN 1',23199),('PALADIN 4',23203)):
  for s in 'ah':assert a['profiles'][c]['references'][s]['gear'][16]['id']==rel
 a['encounter_assumptions']={'eye':13968,'reed':12930,'bonus_spell_power_in_marsh':0,'allied_fire_absorption':0,'rule':'The Eye grants 1% spell critical chance and has a 20-second spell hit on-use. The Reed grants 15 spell power here. Missing non-DPS effects (enemy tracking, ally disarm) do not affect this encounter. Cooldowns for drinking 4696 or banking unabsorbed fire damage with 20036 are inactive.','source_items':['https://www.wowhead.com/forever/item=13968','https://www.wowhead.com/forever/item=12930']}
 a['references_note']='With pre-raid ranged-slot relics 272430 (Balance), 23199 (Elemental), 23203 (Shockadin); Balance uses Headmaster’s Charge with Spellblasting. Each reference is faction-specific. Gains refer only to its exact rotation and gear.'
 j=json.dumps(a,sort_keys=True,indent=1,ensure_ascii=False)
 j=re.sub(r'\[\s*(null|-?[\d.eE+\-]+),\s*(null|[\d.eE+\-]+),\s*(\d+),\s*"([a-z_]+)"\s*\]',r'[\1, \2, \3, "\4"]',j)
 f=d/'caster_trinkets_final.json';f.write_text(j+'\n',encoding='utf8')
 w=read(d/'verification.json');w.update(read(t/'delivery/verification.json'));(d/'verification-finale.json').write_text(json.dumps(w,separators=(',',':')),'utf8')
 print(f,h(f),'rows',sum(len(t)for z in a['profiles'].values()for t in z['contexts'].values()))
 if '--publish' in __import__('sys').argv:
  dest=Path(r'C:/Users/schmi/.codex/worktrees/easybis-audit-final/EasyBIS/_build/corrections/caster_trinkets.json')
  with tempfile.NamedTemporaryFile(dir=dest.parent,delete=False)as fp:fp.write(f.read_bytes());tmp=Path(fp.name)
  tmp.replace(dest);print('Published',h(dest))
