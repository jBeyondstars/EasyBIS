// Item effects WoWSims Forever does not implement, for the items Easy BIS's lists rank.
//
// What each one does is read in the simulator's copy of the game's spell rows and in the items' tooltips. Three of
// them state no rate anywhere: Teebu's Blazing Longsword, Alcor's Sunrazor and Kindling Stave. They take assumedPPM,
// the median of the 165 weapons of the simulator's database that do state one. That number is an assumption.
//
// Cannonball Runner is left out: it summons a cannon, and nothing says how often the cannon fires.
package main

import (
	"os"
	"strconv"
	"time"

	"github.com/wowsims/forever/sim/common/shared"
	"github.com/wowsims/forever/sim/core"
	"github.com/wowsims/forever/sim/core/proto"
	"github.com/wowsims/forever/sim/core/stats"
	"github.com/wowsims/forever/sim/mage"
)

const (
	assumedPPM     = 1.9
	kindlingSpeed  = 2.9 // Kindling Stave's weapon speed: what turns procs per minute into a chance per cast
	burstManaCost  = -150
	chaosFireMax   = 500
	headmasterInt  = 20
	burstDuration  = 10 * time.Second
	chaosFireLasts = time.Minute
)

// The rate of the three procs that state none; EASYBIS_ASSUMED_PPM overrides it, to see what the assumption weighs.
func procsPerMinute() float64 {
	if value, err := strconv.ParseFloat(os.Getenv("EASYBIS_ASSUMED_PPM"), 64); err == nil {
		return value
	}
	return assumedPPM
}

// A "Chance on hit" weapon that blasts its target with the spell's damage.
func weaponBlast(itemID int32, name string, spellID int32, ppm float64) {
	if core.HasItemEffect(itemID) {
		return
	}
	shared.NewSpellDataDamageProc(shared.SpellDataProc{
		TriggerSpellID: spellID,
		BuffSpellID:    spellID,
		IsWeaponProc:   true,
		Rate: func(character *core.Character, trigger *core.ProcTrigger) {
			trigger.ProcChance = 0
			trigger.DPM = character.NewDynamicLegacyProcForWeapon(itemID, ppm, 0)
		},
	}, []shared.ItemVariant{{ItemID: itemID, ItemName: name}})
}

// The item's use: it starts the aura and goes on the item's own cooldown.
func onUse(character *core.Character, itemID int32, aura *core.Aura) {
	var effect *proto.ItemEffect
	for _, candidate := range core.GetItemByID(itemID).ItemEffects {
		if candidate.GetOnUse() != nil {
			effect = candidate
			break
		}
	}
	spell := character.RegisterSpell(core.SpellConfig{
		ActionID: core.ActionID{ItemID: itemID},
		Flags:    core.SpellFlagNoOnCastComplete,
		Cast:     shared.OnUseCast(character, effect),
		ApplyEffects: func(sim *core.Simulation, _ *core.Unit, _ *core.Spell) {
			aura.Activate(sim)
		},
	})
	character.AddMajorCooldown(core.MajorCooldown{Spell: spell, Type: core.CooldownTypeDPS})
}

func fallbackItemEffect(id int32, effect core.ApplyEffect) {
	if !core.HasItemEffect(id) {
		core.NewItemEffect(id, effect)
	}
}

func registerEffects() {
	if os.Getenv("EASYBIS_NO_EFFECTS") != "" {
		return
	}

	// Effects that change no damage: fear resistance, immunity to disarm, removing a disarm from an ally.
	for _, itemID := range []int32{11726, 18722, 13213} { // Savage Gladiator Chain, Death Grips, Smolderweb's Eye
		fallbackItemEffect(itemID, func(core.Agent) {})
	}

	ppm := procsPerMinute()
	weaponBlast(1728, "Teebu's Blazing Longsword", 1300753, ppm) // 140 Fire damage
	weaponBlast(14555, "Alcor's Sunrazor", 18833, ppm)           // 95 to 116 Fire damage

	// Kindling Stave: harmful spell casts have a chance to deal 60 to 81 Fire damage.
	if !core.HasItemEffect(11750) {
		shared.NewSpellDataDamageProc(shared.SpellDataProc{
			TriggerSpellID: 1300781,
			BuffSpellID:    1300782,
			Rate: func(_ *core.Character, trigger *core.ProcTrigger) {
				trigger.DPM = nil
				trigger.ProcChance = ppm * kindlingSpeed / 60
			},
		}, []shared.ItemVariant{{ItemID: 11750, ItemName: "Kindling Stave"}})
	}

	// Headmaster's Charge: 20 intellect for 15 minutes, used before the pull.
	if !core.HasItemEffect(13937) {
		fallbackItemEffect(13937, func(agent core.Agent) {
			agent.GetCharacter().AddStats(stats.Stats{stats.Intellect: headmasterInt})
		})
	}

	// Burst of Knowledge: reduces the mana cost of all spells by 150 for 10 seconds.
	fallbackItemEffect(11832, func(agent core.Agent) {
		character := agent.GetCharacter()
		cost := character.AddDynamicMod(core.SpellModConfig{
			Kind:         core.SpellMod_PowerCost_Flat,
			ResourceType: proto.ResourceType_ResourceTypeMana,
			IntValue:     burstManaCost,
		})
		onUse(character, 11832, character.RegisterAura(core.Aura{
			Label:    "Burst of Knowledge",
			ActionID: core.ActionID{SpellID: 15646},
			Duration: burstDuration,
			OnGain:   func(*core.Aura, *core.Simulation) { cost.Activate() },
			OnExpire: func(*core.Aura, *core.Simulation) { cost.Deactivate() },
		}))
	})

	// Fire Ruby: the next Fire Blast within a minute deals 1 to 500 more damage (spell 24389). What the item's
	// dummy effect restores in mana is stated nowhere, so it is left out.
	if false { fallbackItemEffect(20036, func(agent core.Agent) {
		character := agent.GetCharacter()
		damage := character.AddDynamicMod(core.SpellModConfig{
			Kind:      core.SpellMod_BaseDamage_Flat,
			ClassMask: mage.MageSpellFireBlast,
		})
		// The simulator scales a spell's bonus base damage by the spell's coefficient: this takes it back out.
		coefficient := 1.0
		character.OnSpellRegistered(func(spell *core.Spell) {
			if spell.Matches(mage.MageSpellFireBlast) && spell.BonusCoefficient > 0 {
				coefficient = spell.BonusCoefficient
			}
		})
		onUse(character, 20036, character.RegisterAura(core.Aura{
			Label:    "Chaos Fire",
			ActionID: core.ActionID{SpellID: 24389},
			Duration: chaosFireLasts,
			OnGain: func(_ *core.Aura, sim *core.Simulation) {
				damage.UpdateFloatValue(sim.RollWithLabel(1, chaosFireMax, "Chaos Fire") / coefficient)
				damage.Activate()
			},
			OnExpire: func(*core.Aura, *core.Simulation) { damage.Deactivate() },
			OnSpellHitDealt: func(aura *core.Aura, sim *core.Simulation, spell *core.Spell, _ *core.SpellResult) {
				if spell.Matches(mage.MageSpellFireBlast) {
					aura.Deactivate(sim)
				}
			},
		}))
	}) }
}
