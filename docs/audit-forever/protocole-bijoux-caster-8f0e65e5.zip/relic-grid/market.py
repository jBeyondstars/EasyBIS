from grid_pairs import *
if __name__=='__main__':
 tasks=[]
 for k in RAW:
  a,f=rank(k); top=set([12930,13968])
  for row in f.values():top.update(row[:4])
  default=f[str((k[2],False,False,0,False,5))];top.update(default[:8])
  tasks.extend((*k,i)for i in sorted(top,key=lambda i:(not any(z[0]==i for z in f.values()),i)) if not (P/'tables'/('-'.join(map(str,(*k,i)))+'.json')).exists())
 print('priority, QA',len(tasks),flush=True);run(tasks)
