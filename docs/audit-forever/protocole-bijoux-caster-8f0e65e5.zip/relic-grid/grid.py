from pathlib import Path
import os,json,sys,subprocess,copy,hashlib,concurrent.futures,collections
P=Path(__file__).resolve().parent;T=P.parent.parent.parent;ORIG=P.parent;ROOT=Path(r'C:/Users/schmi/.codex/worktrees/easybis-audit-final/EasyBIS');sys.path.insert(0,str(ROOT/'_build'))
import fdb,ladders,hunter_bm,simulated
read=lambda f:json.loads(f.read_bytes());sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def write(f,o):f.write_text(json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=False),encoding='utf8')
EXE=ORIG/'run.exe';BIN=sha(EXE)
SPECS={'DRUID':(1,),'SHAMAN':(1,),'PALADIN':(4,)}
db=fdb.load(ROOT/'_build/cache/ForeverDB')
# Model parents' repaired metadata before integration and keep published entries if they already exist.
for i,n,stats,source in [(12930,'Briarwood Reed',{45:15},['d','229','Jed Runewatcher','','0','w']),(13968,'Eye of the Beast',{32:14},['q','5102',"General Drakkisath’s Demise",'55','','k'])]:
 if i not in db.items:db.items[i]={'name':n,'groups':frozenset(source[0]),'flags':'sU','side':'','twin':None,'limit':None,'sources':[source],'phase':0}
 if i not in db.gear:db.gear[i]={**db.gear[13213],'stats':stats}
 for cls in SPECS:
  if not any(j==i for j,k in db.classes[cls]['pools']['trinket']):db.classes[cls]['pools']['trinket'].append((i,55))
D={i['id']:i for n in ('leftover_db','db')for i in read(ORIG/'engine/assets/database'/f'{n}.json')['items']}
RAW={};ALL=set()
for c,ns in SPECS.items():
 for s in ns:
  x=ladders.full_ladder(db,c,s,'pve','trinket')
  for side in 'ah':
   es={e.shown(side):e for e in x if e.shown(side)}
   if 13968 not in es:es[13968]=__import__('dataclasses').replace(es[13213],item_id=13968,seen='s' in db.items[13968]['flags'],twin=None)
   assert 12930 in es and 13968 in es,(c,s,side);RAW[c,s,side]=es;ALL.update(es)
(P/'effect-ids.json').write_text(json.dumps(sorted(ALL)));EFFECT=json.loads(subprocess.check_output([str(EXE),'effects',str(P/'effect-ids.json')]))
INV={(r['profile'],r['side'],r['id']):r for r in read(T/'easybis-updated-0764-DPS/inventory-current.json') if r['slot']=='trinket'}
# These secondary effects cannot change boss DPS under this encounter and must not invalidate the actual passive.
BENIGN={12930,20036,13213,275347,17744,18371,19990,20534}
def status(c,n,s,i):
 e=RAW[c,n,s][i];d=D.get(i);rec=INV.get((f'{c} {n}',s,i),{})
 if not d:return 'unmeasured'
 if e.random or d.get('randomSuffixOptions'):return 'unknown_suffix'
 if d.get('procRate',{}).get('status') in (4,5) or rec.get('native_proc_rate_status') in ['unverified','vanilla','inherited','inherited_vanilla']:return 'unverified_proc_rate'
 if rec.get('assumed_proc'):return 'assumed_proc'
 if d.get('itemEffects') and not EFFECT.get(str(i)) and i not in BENIGN:return 'unregistered_effect'
 return 'measured'
def compatible(i,a):
 if not a:return True
 if i==a:return False
 e=D.get(i,{});b=D.get(a,{});lim=e.get('limitCategory');return not(lim and lim==b.get('limitCategory')) and not(db.items.get(i,{}).get('limit') and db.items[i].get('limit')==db.items.get(a,{}).get('limit'))
def produce(c,n,side,anchor):
 ident=f'{c}-{n}-{side}';tag=f'{ident}-{anchor}';es=RAW[c,n,side]
 seed=388241;iterations=2000
 parts=T/'easybis-updated-0764-DPS/jobs'/f'{ident}-trinket.json';q=read(parts);reference=q['jobs'][0];reference=copy.deepcopy(reference);assert reference['key']=='empty'
 if c=='DRUID' and n==1:
  reference['gear'][14]={'id':13937,'enchant':7662};reference['gear'][15]={'id':0,'enchant':0};reference['onUse']=list(dict.fromkeys([*reference.get('onUse',[]),13937]))
 reference['gear'][16]={'id':{'DRUID':272430,'SHAMAN':23199,'PALADIN':23203}[c],'enchant':0}
 assert not any(g.get('id')in set(map(int,read(T/'easybis-soins-jcj-review/negative-missing.json')))for g in reference['gear']),(ident,reference['gear'])
 records={}
 def make(i):
  j=copy.deepcopy(reference);j['key']=str(i) if i else 'empty'
  # Sort both trinkets into a canonical order. The same pair is identical when reached through either first item.
  equipped=sorted(v for v in (i,anchor)if v)
  for index in (0,1):j['gear'][12+index]={'id':equipped[index] if len(equipped)>index else 0,'enchant':0}
  j['onUse']=sorted(set(j.get('onUse',[]))|{id for id in equipped if id not in (20036,4696) and any(effect.get('onUse')for effect in D[id].get('itemEffects',[]))})
  return j
 jobs=[make(0)]
 for i,e in es.items():
  if not compatible(i,anchor):
   records[str(i)]=[None,None,0,'same_unique_category'];continue
  st=status(c,n,side,i);records[str(i)]=[None,None,0,st]
  if st not in ('unknown_suffix','unmeasured'):jobs.append(make(i))
 q.update(jobs=jobs,seed=seed,iterations=iterations);ip=P/'jobs'/f'{tag}.json';op=P/'results'/f'{tag}.json';write(ip,q)
 if not op.exists() or read(op).get('input')!=sha(ip) or read(op).get('engine')!=BIN:
  res=subprocess.run([str(EXE),str(ip)],capture_output=True,env={**os.environ,'GOMAXPROCS':'4'},creationflags=getattr(subprocess,'BELOW_NORMAL_PRIORITY_CLASS',0))
  assert not res.returncode,(tag,res.stderr);rows=json.loads(res.stdout);assert len(rows)==len(jobs) and all(not row.get('error')for row in rows),(tag,rows)
  write(op,{'input':sha(ip),'engine':BIN,'rows':rows})
 rows=read(op)['rows']
 for r in rows[1:]:records[r['key']][:3]=[round(r['diff'],6),round(r['se'],6),iterations]
 return records
def run(tasks):
 with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
  for k,z in zip(tasks,pool.map(lambda k:produce(*k),tasks)):
   write(P/'tables'/('-'.join(map(str,k))+'.json'),z);print(k,flush=True)
if __name__=='__main__':
 for n in ('jobs','results','tables'):(P/n).mkdir(exist_ok=True)
 tasks=[(*k,0)for k in RAW];run(tasks)
