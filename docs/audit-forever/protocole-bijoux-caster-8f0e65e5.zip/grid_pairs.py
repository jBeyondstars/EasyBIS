from grid import *
import time
def rank(k):
 c,n,side=k;es=RAW[k];rs=read(P/'tables'/f'{c}-{n}-{side}-0.json')
 weights=db.classes[c]['specs'][n]['weights']['raid']
 if db.classes[c]['specs'][n]['role']in ('Healer','Caster DPS') and 32 in weights:weights={21:weights[32],**weights}
 w={e.item_id:ladders.score(db,e.item_id,weights,c) or 0 for e in es.values()}
 profiles=[];filters={};anchors=set([13968,12930])
 for f in sorted((f for f in ladders.FILTERS if f[0]==side and f[3]==0),key=str):
  permitted={i for i,e in es.items() if e.passes(f) and rs[str(i)][3]=='measured' and rs[str(i)][0] is not None}
  ranking=sorted(permitted,key=lambda i:(-simulated.rounded(rs[str(i)][0]),-w[es[i].item_id],es[i].item_id))
  if not ranking:continue
  filters[str(f)]=ranking[:10];anchors.update(ranking[:7])
 return anchors,filters
def staged():
 while True:
  tasks=[];remaining=0
  for k in RAW:
   c,n,side=k
   if not(P/'tables'/f'{c}-{n}-{side}-0.json').exists():remaining+=1;continue
   a,f=rank(k);write(P/f'filters-{c}-{n}-{side}.json',f)
   new=[(*k,i) for i in sorted(a) if not(P/'tables'/f'{c}-{n}-{side}-{i}.json').exists()];tasks.extend(new)
  if tasks:
   print('stage',len(tasks),'pool(s) pending',remaining,flush=True);run(tasks)
  elif remaining:time.sleep(3)
  else:break
if __name__=='__main__':staged()
