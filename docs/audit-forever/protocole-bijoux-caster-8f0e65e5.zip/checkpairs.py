from grid_pairs import *
from itertools import combinations
import ast
def scan(k,complete=False):
 c,n,s=k;es=RAW[k];pre=lambda e:e.phase==0
 table=read(P/'tables'/f'{c}-{n}-{s}-0.json')
 def order(records,ids):
  w=db.classes[c]['specs'][n]['weights']['raid']
  if db.classes[c]['specs'][n]['role']in ('Healer','Caster DPS') and 32 in w:w={21:w[32],**w}
  return sorted((i for i in ids if str(i) in records and records[str(i)][3]=='measured' and records[str(i)][0] is not None),key=lambda i:(-simulated.rounded(records[str(i)][0]),-(ladders.score(db,es[i].item_id,w,c)or 0),es[i].item_id))
 cand={}
 for f in (z for z in ladders.FILTERS if z[0]==s and z[3]==0):
  legal=tuple(sorted([i for i,e in es.items()if e.passes(f)]));cand.setdefault(legal,[]).append(f)
 results={};matrix={};firsts=set()
 for fn in (P/'results').glob(f'{c}-{n}-{s}-*.json'):
  anchor=int(fn.stem.rsplit('-',1)[1]);rr=read(fn)['rows']
  if anchor and table[str(anchor)][3]=='measured':
   for x in rr[1:]:
    other=int(x['key']);pair=tuple(sorted((anchor,other)))
    if table[str(other)][3]=='measured' and compatible(anchor,other):
     if pair in matrix and abs(matrix[pair]-x['dps'])>1e-8:raise Exception((c,n,s,pair,matrix[pair],x['dps']))
     matrix[pair]=x['dps']
 for ids,filters in cand.items():
  si=order(table,ids)
  if not si:continue
  first=si[0];firsts.add(first);cond=P/'tables'/f'{c}-{n}-{s}-{first}.json'
  if not cond.exists():continue
  companions=order(read(cond),[i for i in ids if compatible(first,i)])
  if not companions:continue
  second=companions[0];chosen=tuple(sorted((first,second)));selections=sorted(((v,pair)for pair,v in matrix.items()if all(i in ids for i in pair)),reverse=True)
  if not selections:continue
  top_abs,pair=selections[0];gain=top_abs-matrix[chosen]
  # The sample arrays are paired directly in a comparison batch if both compositions share an anchor.
  serror=None; head=next((i for i in chosen if i in pair),None)
  if head and chosen!=pair:
   aa=next(i for i in chosen if i!=head);bb=next(i for i in pair if i!=head);rp=P/'results'/f'{c}-{n}-{s}-{head}.json'
   if rp.exists():
    sub={int(z['key']):z for z in read(rp)['rows'][1:]};serror=sub.get(aa,{}).get('pairSe',{}).get(str(bb),sub.get(bb,{}).get('pairSe',{}).get(str(aa)))
  row={'filters':filters,'first':first,'second':second,'best_combo':pair,'gain_dps_vs_display':gain,'paired_se':serror,'display_dps':matrix[chosen],'best_dps':top_abs,'any_best_includes_first':first in pair,'distinct_pairs_compared':len(selections)}
  results[','.join(map(str,ids))]=row
 return results
if __name__=='__main__':
 result={};default=[]
 for k in RAW:
  cells=scan(k);result[' '.join(map(str,k))]=cells
  for z in cells.values():
   if (k[2],False,False,0,False,5)in z['filters']:default.append((k,z['first'],z['second'],z['best_combo'],round(z['gain_dps_vs_display'],2),z['distinct_pairs_compared']))
 write(P/'windows.json',result);print(default)
