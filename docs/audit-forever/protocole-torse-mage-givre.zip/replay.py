"""Run from the extracted archive with the compiled native AMD64 runner."""
import argparse, hashlib, json, os, subprocess
from pathlib import Path
p = argparse.ArgumentParser()
p.add_argument("runner", type=Path)
a = p.parse_args()
here = Path(__file__).resolve().parent
m = json.loads((here/"calibration.json").read_bytes())
for side, batches in [*m["sources"].items(), ("duels",m["duels"])]:
    for batch in batches:
        src, archived = here/batch["input"], here/batch["output"]
        assert hashlib.sha256(src.read_bytes()).hexdigest() == batch["sha256"]
        assert hashlib.sha256(archived.read_bytes()).hexdigest() == batch["output_sha256"]
        rows = json.loads(subprocess.check_output([str(a.runner.resolve()), str(src)], env={**os.environ, "GOMAXPROCS":"4"}))
        expected = json.loads(archived.read_bytes())
        assert [r["key"] for r in rows] == [r["key"] for r in expected]
        assert all(abs(r["diff"] - e["diff"]) < 1e-7 and abs(r["se"]-e["se"]) < 1e-7
                   for r,e in zip(rows,expected)), (side,src.name)
print("Les 16 lots de calibration et les 6 lots de duels concordent.")
