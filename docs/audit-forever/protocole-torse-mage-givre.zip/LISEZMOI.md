# Mage Givre · torse JcE

Le classement compare chaque torse à un emplacement vide sur deux personnages de niveau 60, une gnome pour l’Alliance et un troll pour la Horde. Les autres pièces sont celles de la tenue pré-raid utilisée pour confronter les choix visibles dans EasyBIS. Les deux portent Channeler's Ring 272406, Rune Band of Wizardry 22339, Sageblade 22383 et Obsidian Bauble 18316. Les équipements complets et les enchantements figurent dans calibration.json. Chaque torse équipé reçoit l’enchantement 1893. Le torse de référence reste vide et sans enchantement.

La grille couvre les 154 identifiants candidats Alliance et 151 Horde du générateur, sur toutes les phases et options d’obtention. La base native permet de mesurer respectivement 153 et 149 torses. Le résultat unregistered_effect de Robes of Insight (940) compte ses statistiques seules. La base ne contient pas 22069, ni 16491 côté Horde. Le malus client de 11 Endurance de 4746 a été rétabli dans la requête. L’effet de réduction de menace de 273044 ne contribue pas au score de DPS sur le boss. Une graine commune (7741329) et 2 000 combats de 180 ±5 s par équipement permettent de mesurer le gain sur emplacement vide et son erreur standard appariée.

## Sept choix au filtre pré-raid, plafond de rang 6, récompenses JcJ exclues

Robe of the Archmage, Robes of Dark Summons, Robe of Winter Night, Alanna’s Embrace, Coldtouch Phantom Wraps, Robe of Everlasting Night et Freezing Lich Robes, dans cet ordre pour chaque faction. Le fichier positions.json restitue le rang sur le score arrondi au demi-DPS dans la liste du générateur. En Alliance, la 6e et la 7e ont la même cote arrondie (22) et leur duel ne les départage pas. Le duel contre la première rivale laisse la première place de la Robe de l’archimage indécise en Alliance (+0,98 ±1,36 DPS) et favorise cette robe en Horde (+3,32 ±1,35).

| Différence de DPS d’Alanna’s Embrace contre Coldtouch Phantom Wraps | Alliance | Horde |
|---|---:|---:|
| Graine 423517 | +2,36 ±0,92 | +3,39 ±0,98 |
| Graine 719263 | +2,97 ±0,95 | +3,62 ±0,97 |
| Graine de calibration 7741329 | +3,21 ±0,90 | +5,35 ±0,95 |

Les valeurs après le signe ± sont les erreurs standard des différences appariées. Dans les duels initiaux, right désigne Alanna et full désigne Coldtouch. L’essai remove-hit retire seulement le toucher de Coldtouch et hit-alone isole sa contribution. Dans les contrôles à la graine 7741329, chaque torse est comparé au torse précédent : RefKey de la ligne 13535 vaut 13314. Les entrées complètes sont jointes pour éviter toute ambiguïté entre un gain individuel sur torse vide et un duel direct.

## Vérification

L’archive contient les entrées, les sorties et leurs SHA-256 dans calibration.json, la configuration proposée à EasyBIS, ainsi que le moteur de calcul du pilote et les sources protobuf générées. Installer Go, extraire le code officiel de https://github.com/wowsims/forever/tree/ceb0e99b77fcf1d9406db66683c7157f92c1597d et copier proto/*.pb.go dans sim/core/proto. Depuis la racine du moteur, fixer GOOS=windows, GOARCH=amd64 et CGO_ENABLED=0, puis compiler avec go build -tags=with_db -o runner.exe <archive>/driver/main.go <archive>/driver/check.go <archive>/driver/effects.go. Exécuter python replay.py <chemin vers runner.exe> depuis le dossier extrait. Le script vérifie les 16 lots de calibration et les six lots complémentaires. Les fichiers d’effet et des classements sont également inclus.
