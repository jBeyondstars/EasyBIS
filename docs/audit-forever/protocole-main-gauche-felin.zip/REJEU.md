# Rejeu de la calibration féline de la main gauche

Le moteur est WoWSims Forever a73af7145111ce19c621e3b5f678553adf326907. Utiliser Python 3 et Go. Le dossier courant des commandes Python est un checkout EasyBIS avec son cache ForeverDB. Disposer les fichiers dans trois répertoires frères. Les pilotes gardent cette convention pour retrouver le moteur et les tenues du contrôle précédent.

- `easybis-cat-off-audit/` contient cette archive.
- `easybis-updated-legal-extra/` contient le protocole général des huit tenues, publié dans `docs/audit-forever/protocole-actualise-feral-tanks.zip`, et son exécutable compilé `runner.exe`.
- `easybis-upstream-a73af714/forever-a73af7145111ce19c621e3b5f678553adf326907/` contient le checkout WoWSims, ses bases natives et ses sources protobuf Go.

Rejouer d’abord le protocole général avec `replay_legal.py --match '^direct-cat-[ah]-off$'`. Ses deux groupes donnent les entrées et duels à main droite Hammer of Grace. Ensuite exécuter, dans l’ordre, les commandes suivantes. Les ensembles `finalists.json` et `second.json` sont figés afin de reproduire exactement le nombre d’itérations. Sur les 221 paires camp/ID, toutes ont reçu 5 000 combats. Les 176 paires avec effet sur le DPS ou sélectionnées pour le contrôle ont été reprises à 20 000.

```powershell
$od = 'C:/audit/easybis-cat-off-audit'
python "$od/duels.py"
python "$od/pool.py" --iterations 5000
python "$od/pool.py" --iterations 20000 --select "$od/finalists.json"
python "$od/pool.py" --iterations 20000 --select "$od/second.json"
python "$od/ablation.py"
```

Les ensembles audit et la rotation par faction viennent de la référence pré-raid féline corrigée. Les duels documentent plusieurs armes à une main. Pour les 128 ID de la main gauche, chaque porteur prend Persuader sans enchantement et conserve les deux bagues et les deux bijoux. La conversion en points compare 40 PA au témoin vide. Toutes les pénalités de caractéristiques manquantes dans WoWSims se trouvent dans `pool.py`, avec l’unité correspondant à la statistique du moteur.

Le contrôle des deux effets utilitaires utilise le même pilote Go avec `veildust.go`. Il empêche la boisson assise de la chope Lapidis en la retirant des CD automatiques. Il mesure également la bourse Veildust sans utilisation et avec cinq retours de 50 mana. Sa disponibilité en forme de félin reste une hypothèse signalée en jeu par un score estimé. Compiler l’exécutable depuis le checkout WoWSims comme pour le protocole général en ajoutant le quatrième fichier, puis effectuer les deux contrôles et vérifier les traces de sort.

```powershell
$wow = 'C:/audit/easybis-upstream-a73af714/forever-a73af7145111ce19c621e3b5f678553adf326907'
$addon = 'C:/audit/EasyBIS'
Set-Location -LiteralPath $wow
$env:GOARCH = 'amd64'
$env:CGO_ENABLED = '0'
go build -tags=with_db -o "$od/runner.exe" "$od/runner/main.go" "$od/runner/check.go" "$od/runner/effects.go" "$od/runner/veildust.go"
Set-Location -LiteralPath $addon
python "$od/utility.py"
python "$od/publish.py"
```

`publish.py` écrit uniquement la donnée de calibration dans `_build/corrections/feral_offhands.json`. Les contrôles de précision dans `stat_ablation` retirent d’abord les 8 Force, Agilité et Endurance du Tome, puis ajoutent les 5 toucher, 14 critique et 8 Esprit successivement. Sur les deux races, la dernière étape reproduit exactement le Sceptre réel. La bourse et la chope ont été rejouées dans des groupes distincts, dont les traces de sorts sont vérifiées.
