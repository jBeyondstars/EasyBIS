from pathlib import Path
import json,os,sys,math,collections,re
from unittest.mock import patch
P=Path(__file__).resolve().parent;ld=lambda f:json.loads(f.read_text(encoding='utf-8-sig'));sys.path.insert(0,str(Path.cwd()/'_build'));import ladders,simulated,fdb,specs
p=ld(P/'pool.json');rows={};raw={};slope={};cases={}
for sub,n in [('pool-5000',5000),('pool-20000',20000),('pool-20000-second',20000)]:
 folder=P/sub
 for f in folder.glob('*.json'):
  if 'input.' in f.name:continue
  side=f.stem[0];v=ld(f)
  if 'ap40' in v:slope[side]=[n,v['ap20'],v['ap40'],v['ap60']]
  for i,pts in v.items():
   if i not in p:continue
   raw.setdefault(i,{})[side]=[n,*pts]
for side in 'ah':
 file=P/f'utility-{side}.json'
 if not file.exists():continue
 z=ld(file);raw['4696'][side]=[20000,*z['4696']];raw['15866'][side]=[20000,*z['15866-on']]
for i,info in p.items():assert set(raw[i])==set(info['sides'])
groups=collections.defaultdict(list)
for i,info in p.items():groups[info['occurrence']].append(i)
d=fdb.load('_build/cache/ForeverDB');weights=d.classes['DRUID']['specs'][4]['weights']['raid'];w=weights[specs.ATTACK_POWER];th=d.classes['DRUID']['min']['raid']
scores={}
for group,objects in groups.items():
 vals=[]
 for id in objects:
  vals.extend(w*40*z[1]/slope[s][2][0] for s,z in raw[id].items())
 score=sum(vals)/len(vals)
 if score>=th or max(p[id]['original_score'] for id in objects)>=th:
  for i in objects:scores[int(i)]=round(max(0,score),3)
rg=simulated.SlotRanking(scores,1,float('inf'),frozenset({15866}));old=ladders.full_ladder(d,'DRUID',4,'pve','off'); 
with patch.object(simulated,'ranking',return_value=rg):new=ladders.full_ladder(d,'DRUID',4,'pve','off')
print('old/new',len(old),len(new),'kept',[(e.item_id,round(e.score,3),p[str(e.item_id)]['name'],[v[0] for v in raw[str(e.item_id)].values()]) for e in ladders.kept_ladder('off',new)]);print('ap',slope);print('missing final', [e.item_id for e in ladders.kept_ladder('off',new) if min(v[0] for v in raw[str(e.item_id)].values())<20000]);print('source known',len([i for i,z in p.items() if len(z['sides'])==2]))
