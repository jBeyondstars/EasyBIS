from pathlib import Path
import os,json,copy,subprocess,concurrent.futures
P=Path(__file__).resolve().parent;L=P.parent/'easybis-updated-legal-extra';ld=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
def run(side):
 q=ld(P/f'{side}-persuader.input.json');base=copy.deepcopy(q['jobs'][0]);seq=[];past='';bonus={}
 for k,m in [('Tome',{}),('physical',{'0':-8,'1':-8,'2':-8}),('hit',{'17':5}),('crit',{'18':14}),('spirit',{'13':8})]:
  j=copy.deepcopy(base);bonus.update(m);j['Bonus']=dict(bonus);j['key']=k;j['RefKey']=past;seq.append(j);past=k
 j=copy.deepcopy(q['jobs'][1]);j['key']='Scepter';j['RefKey']=past;seq.append(j);q['jobs']=seq;fp=P/f'{side}-ablation.input.json';fp.write_text(json.dumps(q));z=json.loads(subprocess.run([str(L/'runner.exe'),str(fp)],env={**os.environ,'GOMAXPROCS':'5'},capture_output=True,check=True).stdout);att={v['key']:[round(v['dps']-z[max(j-1,0)]['dps'],5),round(v['se'],5)] for j,v in enumerate(z)};assert att['Scepter']==[0,0];(P/f'{side}-ablation.json').write_text(json.dumps(att));print(side,att)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as e:list(e.map(run,'ah'))
