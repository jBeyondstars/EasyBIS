from pathlib import Path
import json,os,re
from calculate import P,ld,p,groups,raw,slope,weights,w,specs,d
dest=Path('_build/corrections/feral_offhands.json')
data={'about':"Feral cat PvE off-hand only. WoWSims boss at 180 +/- 5 seconds. Fractional DPS gains are converted with ForeverDB's 0.244 points per attack power and a paired +40 AP calibration on each faction. Each trial is [actual ID, faction, DPS vs empty hand, paired standard error, iteration count]. The guard keeps the existing stat-weight threshold for newly admitted items. Faction-twin scores use the measured variants only.",'wowsims':'a73af7145111ce19c621e3b5f678553adf326907','date':'2026-11-22','reference':{'main_hand':22384,'gear_and_rotation':'docs/audit-forever/protocole-actualise-feral-tanks.zip, legality.json, profiles.cat. Each faction sets main hand to Persuader with no enchant. Both fingers/trinkets stay equipped.','seed':4242,'duration_seconds':180,'duration_variation_seconds':5,'negative_stats':{'4696':{'agility':-15},'18425':{'intellect':-20},'284228':{'stamina':-10},'284668':{'stamina':-5},'5611':{'spirit':-3}},'drinks_excluded':[4696,273137,286541],'tome_effect':'Stealth level has no impact on these boss attacks.','medicine_bag':{'id':15866,'spell':19634,'active':'Five ticks of 50 mana at three-second intervals, once when missing at least 250 mana. Use while in form is unverified. Score is estimated.','passive':{s:ld(P/f'utility-{s}.json')['15866'] for s in 'ah'}}},'calibration_ap':40,'calibration':{s:v[2] for s,v in slope.items()},'estimated':[15866],'duels_scepter_minus_tome':{},'candidates':[]}
for case in ('hammer_of_grace','persuader','heartseeker','greenhammer','hitgear'):
 ds={}
 for side in 'ah':
  if case=='hammer_of_grace':
   c=ld(P.parent/'easybis-updated-legal-extra'/'groups'/f'direct-cat-{side}-off.json')['Scepter'];ds[side]=c[:2]
  else:
   c=ld(P/f'{side}-{case}.json');ds[side]=[round(c[1]['dps']-c[0]['dps'],5),round(c[1]['se'],5)]
 data['duels_scepter_minus_tome'][case]=ds
if all((P/f'{s}-ablation.json').exists() for s in 'ah'):data['stat_ablation']={s:ld(P/f'{s}-ablation.json') for s in 'ah'}
items=[]
for canonical,ids in sorted(groups.items()):
 trials=[]
 for i in ids:
  for s,(iters,mean,se) in sorted(raw[i].items()):
   trials.append([int(i),s,mean,se,iters])
 entry={'id':canonical,'trials':trials}
 if any(p[id]['original_score']>=1 for id in ids):entry['weighted_candidate']=True
 items.append(entry)
text=json.dumps({k:v for k,v in data.items() if k!='candidates'},indent=2,ensure_ascii=False)
dest.write_text(text[:-2]+',\n  "candidates": [\n'+',\n'.join('    '+json.dumps(x,ensure_ascii=False,separators=(',',':')) for x in items)+'\n  ]\n}\n',encoding='utf8')
