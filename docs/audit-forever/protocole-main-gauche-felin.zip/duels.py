from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,os,sys,subprocess,copy
P=Path(__file__).resolve().parent;L=P.parent/'easybis-updated-legal-extra';ld=lambda f:json.loads(f.read_text(encoding='utf-8-sig'));write=lambda f,x:f.write_text(json.dumps(x,separators=(',',':')),encoding='utf8')
facts=ld(L/'legality.json')['facts'];native_path=L.parent/'easybis-upstream-a73af714'/'forever-a73af7145111ce19c621e3b5f678553adf326907'/'assets/database'
native={x['id']:x for fn in ('db.json','leftover_db.json') for x in ld(native_path/fn)['items']}
def run(args):
 side,name,mh,other=args;q=ld(L/'groups'/f'direct-cat-{side}-off.input.json')
 for j in q['jobs']:
  gear=j['gear'];gear[14]={'id':mh,'enchant':0}
  for index,i in other.items():gear[index]['id']=i
  assert all(not x['id'] or (side in facts[str(x['id'])]['sides'] and facts[str(x['id'])]['phase']==0 and facts[str(x['id'])]['rank']<=6 and facts[str(x['id'])]['known_source']) for x in gear)
  assert native[mh]['handType'] in (1,2) and native[mh]['weaponType'] in (2,3,4,6,8)
  for index,i in other.items():
   assert native[i]['type']==index+1 and native[i].get('armorType',0)<=2
 tag=side+'-'+name;fp=P/(tag+'.input.json');out=P/(tag+'.json');write(fp,q)
 if not out.exists():
  val=json.loads(subprocess.check_output([str(L/'runner.exe'),str(fp)],env={**os.environ,'GOMAXPROCS':'5'}));write(out,val)
 res=ld(out);assert all(not row.get('error') for row in res)
 hit=sum(native[x['id']].get('scalingOptions',{}).get('0',{}).get('stats',{}).get('17',0) for pos,x in enumerate(q['jobs'][0]['gear']) if x['id'] and pos!=15)
 print(tag,hit,'ratings',round(res[1]['dps']-res[0]['dps'],4),round(res[1]['se'],4),flush=True)
if __name__=='__main__':
 cfg=[(s,name,mh,other) for s in 'ah' for name,mh,other in [('greenhammer',279261,{}),('persuader',22384,{}),('heartseeker',12783,{}),('hitgear',22384,{1:22150,2:12927,3:272414,4:252483,5:12966})]]
 with ThreadPoolExecutor(max_workers=4) as e:list(e.map(run,cfg))
