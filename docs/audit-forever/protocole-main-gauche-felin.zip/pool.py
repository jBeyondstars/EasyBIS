"""Build the complete eligible PvE off-hand pool, including candidates with weight zero, then measure it on a fixed 1H."""
import argparse,collections,concurrent.futures,copy,hashlib,json,os,re,subprocess,sys
from pathlib import Path
from unittest.mock import patch
P=Path(__file__).resolve().parent;L=P.parent/'easybis-updated-legal-extra';ld=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
def write(p,d):p.write_text(json.dumps(d,separators=(',',':'),ensure_ascii=False),encoding='utf8')
ap=argparse.ArgumentParser();ap.add_argument('--iterations',type=int,default=10000);ap.add_argument('--workers',type=int,default=4);ap.add_argument('--cpu',type=int,default=4);ap.add_argument('--select',type=Path);args=ap.parse_args()
sys.path.insert(0,str(Path.cwd()/'_build'));import fdb,ladders,simulated
db=fdb.load('_build/cache/ForeverDB');origL=ladders.full_ladder(db,'DRUID',4,'pve','off');r=simulated.SlotRanking({i:1 for i in db.items},1,0,frozenset())
with patch.object(simulated,'ranking',return_value=r):full=ladders.full_ladder(db,'DRUID',4,'pve','off')
old=ld(L/'legality.json')['facts'];eng=L.parent/'easybis-upstream-a73af714'/'forever-a73af7145111ce19c621e3b5f678553adf326907'/'assets/database';nat={x['id']:x for n in ['db.json','leftover_db.json'] for x in ld(eng/n)['items']};ids={}
for it in full:
 for side in 'ah':
  i=it.shown(side)
  if not i:continue
  data=nat[i];assert data['type']==13 and data['weaponType']==5 and data['handType']==3 and not data.get('randomSuffixOptions') and (not data.get('classAllowlist') or 11 in data['classAllowlist'])
  if side not in old.get(str(i),{'sides':'ah'})['sides']:continue
  restriction=data.get('factionRestriction')
  if restriction and restriction!={'a':1,'h':2}[side]:continue
  if i not in ids:ids[i]={'sides':'','name':data['name'],'original_score':next((x.score for x in origL if x.item_id==it.item_id),0),'occurrence':it.item_id}
  ids[i]['sides']+=side
# Faction information for sources: when only one camp supplies a BoP quest reward, restrict this fixed scenario to it.
for i,record in ids.items():
 x=nat[i];inf=old.get(str(i))
 if not inf:
  sources=x.get('sources',[]); restrictions=set()
  for src in sources:
   kind,src=next(iter(src.items()));who=src.get('faction') or src.get('factionId') or {2799:1,2798:2,509:1,510:2,729:2,730:1,889:2,890:1}.get(src.get('repFactionId'))
   restrictions.update({1:'a',2:'h'}.get(who,'ah'))
  if restrictions:record['sides']=''.join(s for s in record['sides'] if s in restrictions)
 assert record['sides'],(i,record)
write(P/'pool.json',ids);print('Full eligible catalogue',len(full),'primary /',len(ids),'actual IDs',flush=True)
subset=set(map(int,ld(args.select))) if args.select else set(ids);jobdir=P/(f'pool-{args.iterations}'+('-second' if args.select is not None and args.select.stem=='second' else ''));jobdir.mkdir(exist_ok=True)
def run_tag(arg):
 side,ix,group=arg;tag=f'{side}-{ix:02d}';out=jobdir/(tag+'.json');inp=jobdir/(tag+'.input.json')
 q=ld(P/f'{side}-persuader.input.json');q['iterations']=args.iterations;src=q['jobs'][0];src['gear'][15]={'id':0,'enchant':0};src['key']='empty';src['RefKey']='';q['jobs']=[src]
 if ix==0:
  for ap in (20,40,60):
   v=copy.deepcopy(src);v['key']='ap'+str(ap);v['Bonus']={'14':ap};q['jobs'].append(v)
 for i in group:
  item=nat[i];j=copy.deepcopy(src);j['key']=str(i);j['gear'][15]={'id':i,'enchant':0};uses=[]
  # These five effects are drinks, movement, a heal, or a Dark Iron dwarf charm. None is a boss DPS cooldown.
  penalties={4696:{'1':-15},18425:{'3':-20},284228:{'2':-10},284668:{'2':-5},5611:{'13':-3}}
  if i in penalties:j['Bonus']=penalties[i]
  if any('onUse' in e for e in item.get('itemEffects',[])) and i not in {4696,4984,11625,16768,273137}:raise ValueError(('review use effect',i))
  j['onUse']=uses;q['jobs'].append(j)
 if not out.exists() or not inp.exists() or ld(inp)!=q:
  write(inp,q);ret=subprocess.run([str(L/'runner.exe'),str(inp)],env={**os.environ,'GOMAXPROCS':str(args.cpu)},capture_output=True);ret.check_returncode();v=json.loads(ret.stdout);assert len(v)==len(q['jobs']) and not any(x.get('error') for x in v);write(out,{x['key']:[round(x['dps']-v[0]['dps'],5),round(x['se'],5)] for x in v})
 print(tag,len(q['jobs']),flush=True)
cmd=[]
for side in 'ah':
 selected=[i for i,z in sorted(ids.items()) if side in z['sides'] and i in subset]
 for j in range(0,len(selected),8):cmd.append((side,j//8,selected[j:j+8]))
with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as e:list(e.map(run_tag,cmd))
