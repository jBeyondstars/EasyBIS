from pathlib import Path
import os,json,copy,subprocess,concurrent.futures
P=Path(__file__).resolve().parent; ld=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
def run(s):
 q=ld(P/f'{s}-persuader.input.json');q['iterations']=20000
 src=q['jobs'][0];src['gear'][15]={'id':0,'enchant':0};src['key']='empty';src['RefKey']='';q['jobs']=[src]
 rot=q['base']['raid']['parties'][0]['players'][0]['rotation'];rot['priorityList'].insert(0,{'action':{'condition':{'cmp':{'op':'OpLt','lhs':{'const':{'val':'1'}},'rhs':{'const':{'val':'0'}}}},'castSpell':{'spellId':{'itemId':4696}}}})
 for i,active in [(4696,False),(15866,False),(15866,True)]:
  j=copy.deepcopy(src);j['gear'][15]={'id':i,'enchant':0};j['key']=str(i)+('-on' if active else '');j['onUse']=[i] if active else []
  if i==4696:j['Bonus']={'1':-15}
  q['jobs'].append(j)
 tag='utility-'+s;fp=P/(tag+'.input.json');fp.write_text(json.dumps(q));v=json.loads(subprocess.run([str(P/'runner.exe'),str(fp)],env={**os.environ,'GOMAXPROCS':'6'},capture_output=True,check=True).stdout)
 assert all(not x.get('error') for x in v);res={x['key']:[round(x['dps']-v[0]['dps'],5),round(x['se'],5)] for x in v};(P/(tag+'.json')).write_text(json.dumps(res));print(tag,res,flush=True)
 # Verify via the simulator's cast trace that the drink remains unused and the bag really fires.
 for j in q['jobs'][1:]:
  check={**q,'iterations':5,'jobs':[j]};fp=P/(tag+'-'+j['key']+'-check.json');fp.write_text(json.dumps(check))
  c=json.loads(subprocess.run([str(P/'runner.exe'),'check',str(fp)],capture_output=True,check=True).stdout)
  assert c['casts'].get('item 4696',0)==0 and bool(c['casts'].get('item 15866',0))==j['key'].endswith('-on')
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as e:list(e.map(run,'ah'))
