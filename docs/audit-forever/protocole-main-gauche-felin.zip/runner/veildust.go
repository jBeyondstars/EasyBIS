package main

import (
    "time"
    "github.com/wowsims/forever/sim/core"
)

// The bag casts Mana Rejuvenation (19634). The Forever tooltip gives five
// ticks of 50 mana, one every three seconds, with a 30-minute item cooldown.
func init() {
    core.NewItemEffect(15866, func(agent core.Agent) {
        c := agent.GetCharacter()
        metrics := c.NewManaMetrics(core.ActionID{SpellID: 19634})
        c.RegisterSpell(core.SpellConfig{
            ActionID: core.ActionID{ItemID: 15866},
            Flags: core.SpellFlagAPL,
            Cast: core.CastConfig{CD: core.Cooldown{Timer: c.NewTimer(), Duration: 30 * time.Minute}},
            ExtraCastCondition: func(sim *core.Simulation, target *core.Unit) bool {
                return c.MaxMana() - c.CurrentMana() >= 250
            },
            ApplyEffects: func(sim *core.Simulation, target *core.Unit, spell *core.Spell) {
                core.StartPeriodicAction(sim, core.PeriodicActionOptions{
                    Period: 3 * time.Second, NumTicks: 5,
                    OnAction: func(sim *core.Simulation) { c.AddMana(sim, 50, metrics) },
                })
            },
        })
    })
}
