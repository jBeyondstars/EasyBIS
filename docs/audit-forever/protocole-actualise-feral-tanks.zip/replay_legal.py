"""Build a complete, legality-checked experiment plan and replay it on the instrumented pinned engine."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import argparse,copy,collections,hashlib,json,os,re,subprocess,time
P=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,d):
 tmp=p.with_suffix('.part');tmp.write_text(json.dumps(d,ensure_ascii=False,separators=(',',':')),encoding='utf8');tmp.replace(p)
parser=argparse.ArgumentParser();parser.add_argument('--engine',type=Path,default=Path(os.environ.get('TEMP','.'))/'easybis-upstream-a73af714'/'forever-a73af7145111ce19c621e3b5f678553adf326907');parser.add_argument('--cpu',type=int,default=8);parser.add_argument('--workers',type=int,default=2);parser.add_argument('--plan-only',action='store_true');parser.add_argument('--theoretical',action='store_true');parser.add_argument('--match',default='');args=parser.parse_args()
old=read(P/'initial-results.json');new=read(P/'legality.json');forms=new['profiles'];fact={int(i):v for i,v in new['facts'].items()};enchs={int(i):v for i,v in new['enchants'].items()};seats=new['slots']
item={i['id']:i for fn in ('db.json','leftover_db.json') for i in read(args.engine/'assets/database'/fn)['items']}
catalogue=read(P/'catalogue.json')['rows']
class_name={'cat':'Druid','bear':'Druid','war':'Warrior','pal':'Paladin'}
weapons={'cat':{2,3,4,5,6,8},'bear':{2,3,4,5,6,8},'war':set(range(1,10)),'pal':{1,4,5,6,7,9}}
validraw={};excluded={};plans=collections.defaultdict(dict);anchored={};printable={}
side_names={'a':'Alliance','h':'Horde'}
def itemcheck(f,side,i,pos,consider_access=True):
 x=item.get(i)
 if not x:return 'absent'
 if x.get('randomSuffixOptions'):return 'suffix'
 a=fact[i];cl=new['classes'][f]
 if a['tip_classes'] and class_name[f] not in a['tip_classes'] or x.get('classAllowlist') and cl not in x['classAllowlist']:return 'class'
 if x.get('reqLvl',0)>60:return 'level'
 if side not in a['sides']:return 'faction'
 if consider_access and not a['known_source']:return 'unknown_source'
 if consider_access and a['rank']==99:return 'legacy_unsold'
 if x.get('armorType',0)>(2 if f in ('cat','bear') else 4):return 'armor'
 tp=x.get('type',0);hand=x.get('handType');weap=x.get('weaponType');rng=x.get('rangedWeaponType')
 if pos<=9:fits=tp==pos+1
 elif pos in (10,11):fits=tp==11
 elif pos in (12,13):fits=tp==12
 elif pos==14:fits=tp==13 and hand in (1,2,4) and weap in weapons[f]
 elif pos==15:fits=tp==13 and hand==3 and weap in weapons[f] and weap==(5 if f in ('cat','bear') else 7)
 else:fits=tp==14 and (rng in (1,2,3,4) if f=='war' else rng==(7 if f=='pal' else 6))
 return '' if fits else 'slot_or_weapon'
def enchantfits(e,i,f,side):
 if not e or not i:return 0
 x=item[i];tp=x.get('type');hand=x.get('handType');weap=x.get('weaponType')
 for row in enchs[e]:
  ty=row.get('enchantType',0)
  if not any(not src.get('faction') or src['faction']=={'a':1,'h':2}[side] for typ in row.get('sources',[]) for src in typ.values()):continue
  if any(prefix+str(row.get(key)) in new['raid_enchants'] for prefix,key in [('s','spellId'),('i','itemId')]):continue
  if row.get('classAllowlist') and new['classes'][f] not in row['classAllowlist']:continue
  if tp not in (row.get('type'),*row.get('extraTypes',[])):continue
  if ty==1 and hand!=4 or (ty==2)!=(weap==7) or (ty==5)!=(weap==5):continue
  if ty==4 and weap!=8:continue
  return e
 return 0
def conflicts(i,g):
 a=fact[i];x=item[i];cats=x.get('limitCategory')
 hits=[]
 for pos,b in enumerate(g):
  if not b:continue
  if b==i and (x.get('unique') or a['quest_only']) or cats and item[b].get('limitCategory')==cats or (a['quest_only'] and fact[b]['quest_only'] and bool(set(a['quest_only']) & set(fact[b]['quest_only']))):hits.append(pos)
 return hits
def basegear(f,side,slot):
 ret=forms[f][side]['gear'].copy()
 for pos,s in enumerate(seats):
  if s==slot:ret[pos]=0
 if slot=='main' and f in ('cat','bear'):ret[15]=0
 if slot=='off' and f in ('cat','bear'):ret[14]=11923
 return ret
def validate(f,side,gear,allow_id=0):
 check=set()
 for pos,i in enumerate(gear):
  if not i:continue
  issue=itemcheck(f,side,i,pos,consider_access=i!=allow_id)
  if issue:raise ValueError(('invalid loadout',f,side,i,seats[pos],issue))
  other=gear.copy();other[pos]=0
  if conflicts(i,other):raise ValueError(('unique/quest',f,side,i,gear))
  check.update(fact[i]['prof'])
 if gear[15] and gear[14] and item[gear[14]]['handType']==4:raise ValueError(('twohand+off',gear))
 if len(check)>2:raise ValueError(('profession conflict',check))
 return check
def professions(f,req):
 initial=['Engineering','Enchanting'] if f=='pal' else ['Engineering','Leatherworking' if f in ('cat','bear') else 'Blacksmithing']
 return tuple(dict.fromkeys([*sorted(req),*initial]))[:2]
def job(label,g,f,side,refkey='',stock=False,activation=None):
 ref=forms[f][side];eq=[{'id':i,'enchant':enchantfits(ref['enchants'][pos],i,f,side)} for pos,i in enumerate(g)]
 rot=json.dumps(ref['base']['raid']['parties'][0]['players'][0]['rotation'])
 uses=sorted({i for i in g if i and any('onUse' in e for e in item[i].get('itemEffects',[])) and not re.search(r'"itemId":\s*'+str(i)+r'\b',rot) and i!=4696 and not(f=='cat' and i==280065)}) if activation is None else activation
 j={'key':label,'gear':eq,'onUse':uses,'RefKey':refkey}
 delta=sum(old['shield_corrections'].get(str(i),{}).get('delta',0) for i in g) if not stock else 0
 bonus={'24':delta} if delta else {}
 if 284228 in g:bonus['2']=-10  # Client tooltip; the native WoWSims item omits this Stamina penalty.
 if bonus:j['Bonus']=bonus
 return j
def addplan(tag,f,side,pri,n,jobs):
 cfg=copy.deepcopy(forms[f][side]['base']);pl=cfg['raid']['parties'][0]['players'][0]
 pl['profession1'],pl['profession2']=pri
 plans[tag]={'base':cfg,'jobs':jobs,'iterations':n,'seed':4242,'duration':180}
def setcandidate(f,side,slot,i):
 if not any(side in who for who in catalogue[f][slot][str(i)].values()):return 'catalogue_faction'
 base=basegear(f,side,slot);pos=seats.index(slot)
 issue=itemcheck(f,side,i,pos)
 if args.theoretical:
  if issue not in ('unknown_source','legacy_unsold'):return issue or 'covered'
  if restriction:=itemcheck(f,side,i,pos,consider_access=False):return restriction
 elif issue:return issue
 for b in conflicts(i,base):base[b]=0
 if slot=='main' and item[i].get('handType')==4:base[15]=0
 g=base.copy();g[pos]=i
 req=validate(f,side,g,allow_id=i if args.theoretical else 0);validate(f,side,base)
 pri=professions(f,req);tag='-'.join([f,side,slot,*pri])
 sig=hashlib.sha256(repr(base).encode()).hexdigest()[:12];ref='base-'+sig
 group=anchored.setdefault(tag,(f,side,pri,{}))[3];group.setdefault(ref,job(ref,base,f,side))
 group[str(i)]=job(str(i),g,f,side,ref)
 if slot=='off' and f in ('war','pal') and str(i) in old['shield_corrections']:group['stock-'+str(i)]=job('stock-'+str(i),g,f,side,str(i),stock=True)
 validraw[f,side,slot,i]=[tag,ref]
 return ''
for f,sides in forms.items():
 for side,profile in sides.items():
  validate(f,side,profile['gear'])
  for pos,i in enumerate(profile['gear']):
   if i and profile['enchants'][pos] and enchantfits(profile['enchants'][pos],i,f,side)!=profile['enchants'][pos]:raise ValueError(('baseline enchant',f,side,pos,i))
  for slot,items in catalogue[f].items():
   for i in map(int,items):
    reason=setcandidate(f,side,slot,i)
    if reason:excluded[f,side,slot,i]=reason
for tag,(f,side,pri,jobs) in anchored.items():addplan(tag,f,side,pri,2000,list(jobs.values()))
pairs={'back':('back',[('Blackveil',11626,[]),('Howler',272414,[])]),'finger':('finger',[('Cutthroat',272408,[]),('Warden',275981,[])]),'head':('head',[('Outlaw',279253,[]),('Eye',12587,[]),('Wolfshead',8345,[])]),'main':('main',[('Glaive',250619,[]),('Bonecrusher',18420,[])]),'off':('off',[('Tome',13385,[]),('Scepter',22329,[])]),'trinket':('trinket',[('empty',0,[]),('passive',280065,[]),('activation',280065,[280065]),('Lucky',280060,[])]),'trinket-supplement':('trinket',[('Bones passif',280065,[]),('Lucky non forcé',280060,[]),('Lucky forcé',280060,[280060])])}
for f in (() if args.theoretical else ('cat','war','pal')):
 for side in forms[f]:
  examples=pairs if f=='cat' else {'shields':('off',[(str(i),i,None) for i in (12602,279262,18168,18499)])}
  for kind,(s,opts) in examples.items():
   jobs=[];req=set()
   for name,i,act in opts:
    g=basegear(f,side,s);g[seats.index(s)]=i;req.update(validate(f,side,g));jobs.append(job(name,g,f,side,activation=act))
   addplan(f'direct-{f}-{side}-{kind}',f,side,professions(f,req),20000 if f=='cat' else 2000,jobs)
outdir=P/('groups-conditional' if args.theoretical else 'groups');outdir.mkdir(exist_ok=True)
meta={'engine':old['engine'],'reference':forms,'cases':{'/'.join(map(str,k)):v for k,v in validraw.items()},'exclusions':{'/'.join(map(str,k)):v for k,v in excluded.items()},'checks':{tag:len(v['jobs']) for tag,v in plans.items()}}
write(P/('plan-conditional.json' if args.theoretical else 'plan.json'),meta)
print('Plan:',len(validraw),'faction-specific substitutions;',len(plans),'groups.',collections.Counter(excluded.values()),flush=True)
def run(q):
 tag,cfg=q;out=outdir/f'{tag}.json';inp=outdir/f'{tag}.input.json'
 whole=cfg;cached={};delta_input=outdir/f'{tag}.pending-input.json'
 if out.exists() and inp.exists():
  before=read(inp);measured=read(out);prev={v['key']:v for v in before['jobs']}
  if cfg==before and all(j['key'] in measured for j in cfg['jobs']):return
  if all(before.get(k)==v for k,v in cfg.items() if k!='jobs') and before['jobs'][0]==cfg['jobs'][0]:
   desired={j['key']:j for j in cfg['jobs']}
   same={k for k,j in desired.items() if prev.get(k)==j and k in measured}
   ready={k for k in same if not desired[k].get('RefKey') or desired[k]['RefKey'] in same}
   pending=set(desired)-ready
   cached={k:measured[k] for k in ready}
   if not pending:
    write(out,cached);write(inp,cfg);return
   needed=pending | {cfg['jobs'][0]['key']}
   for k in list(needed):
    while desired[k].get('RefKey'):
     k=desired[k]['RefKey'];needed.add(k)
   cfg={**cfg,'jobs':[j for j in cfg['jobs'] if j['key'] in needed]}
 write(delta_input,cfg);start=time.monotonic()
 p=subprocess.run([str(P/'runner.exe'),str(delta_input)],env={**os.environ,'GOMAXPROCS':str(args.cpu)},capture_output=True)
 if p.returncode:raise RuntimeError((tag,p.stderr.decode(errors='replace')[-1300:]))
 vals=json.loads(p.stdout);rows={v['key']:v for v in vals}
 if any(v.get('error') for v in vals) or len(rows)!=len(cfg['jobs']):raise ValueError((tag,[(k,v.get('error')) for k,v in rows.items() if v.get('error')]))
 res={}
 for n,j in enumerate(cfg['jobs']):
  k=j['key'];v=rows[k];a=rows[j['RefKey']] if j.get('RefKey') else rows[ cfg['jobs'][0]['key'] ]
  res[k]=[round(v['dps']-a['dps'],4),round(v['se'],4),round(v['Threat']-a['Threat'],4),round(v['Incoming']-a['Incoming'],4),round(v['TMI']-a['TMI'],4),round(v['ThreatSE'],4),round(v['IncomingSE'],4)]
  if k.startswith('base-') and (v['dps']<=0 or tag.startswith(('bear','war','pal')) and v['Incoming']<=0):raise ValueError((tag,k,'unusable baseline'))
 cached.update(res);assert set(cached)=={j['key'] for j in whole['jobs']};write(out,cached);write(inp,whole);delta_input.unlink(missing_ok=True);print(f'{tag} {len(cfg["jobs"])} jobs {time.monotonic()-start:.1f}s',flush=True)
if not args.plan_only:
 with ThreadPoolExecutor(max_workers=args.workers) as e:list(e.map(run,sorted(((k,v) for k,v in plans.items() if re.search(args.match,k)),key=lambda kv:(not kv[0].startswith('direct'),kv[0]))))
