import json,os,requests,re,html,threading,time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
p=Path(__file__).resolve().parent;t=p.parent
d=json.loads((p/'initial-results.json').read_text(encoding='utf8'))
ids={int(i) for v in d['profiles'].values() for cases in v['modes'].values() for i in cases}
cat=json.loads((p/'catalogue.json').read_text())['rows'];ids.update(int(i) for s in cat.values() for cases in s.values() for i in cases)
ids.update(i for v in d['profiles'].values() for i in v['gear'] if i)
ids.update([272105,22740,17909,18375,16734,16729,17705,17713,13965,15411,12602,14557,11923,18499,12553,19323,21202,18022,18406,11815,17774,18428])
target=p/'tooltips';target.mkdir(exist_ok=True)
tls=threading.local()
def one(i):
 f=target/f'{i}.json'
 if f.exists():return
 cached=t/'easybis-shield-tooltips'/f'{i}.json'
 if cached.exists():f.write_bytes(cached.read_bytes());return
 if not hasattr(tls,'s'):tls.s=requests.Session()
 for tries in range(4):
  try:
   h=tls.s.get(f'https://nether.wowhead.com/tooltip/item/{i}',params={'dataEnv':16,'locale':0},timeout=12)
   if h.status_code in (404,410):f.write_text('{}');return
   h.raise_for_status();a=h.json();f.write_text(json.dumps(a,ensure_ascii=False),encoding='utf8');return
  except Exception:time.sleep(tries+1)
 print('unread',i,flush=True)
with ThreadPoolExecutor(max_workers=8) as e:list(e.map(one,sorted(ids)))
print('tooltips',len(list(target.glob('*.json'))),'requested',len(ids),flush=True)
