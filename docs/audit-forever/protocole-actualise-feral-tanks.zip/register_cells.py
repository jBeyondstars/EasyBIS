"""Write the French audit cells after validating the actual catalogue ID in each specialization, mode and slot."""
import argparse,json,os,re
from pathlib import Path
from collections import Counter
p=argparse.ArgumentParser();p.add_argument('root',type=Path,nargs='?',default=Path.cwd());p.add_argument('--results',type=Path);p.add_argument('--output',type=Path,default=Path(os.environ.get('TEMP','.'))/'easybis-new-extra-column.json');args=p.parse_args()
root=args.root.resolve();obs=json.loads((args.results or root/'docs/audit-forever/controle-actualise-feral-tanks.json').read_text(encoding='utf8'))
profiles={('DRUID',4):'cat',('DRUID',2):'bear',('WARRIOR',3):'war',('PALADIN',2):'pal'}
keys={}
for line in (root/'Data/Lists.lua').read_text(encoding='utf8').splitlines():
 if m:=re.match(r'^([A-Z]+) = \[==\[',line):cls=m[1]
 if not line.startswith('L\t'):continue
 _,sp,mode,slot,tokens=line.split('\t');sp=int(sp)
 if (cls,sp) not in profiles:continue
 for token in tokens.split():
  i,_,flags,twin,*rest=(token+':'*6).split(':');side=next((v for v in 'ah' if v in flags),'ah')
  for id,s in [(i,side)]+([(twin,{'a':'h','h':'a'}[side])] if twin else []):
   keys.setdefault((cls,sp,mode,slot,int(id)),set()).update(s)
def n(v,signed=False):
 v=round(v,2)
 if v==0:return '0'
 return ('+' if signed and v>0 else '−' if v<0 else '')+f'{abs(v):.2f}'.replace('.',',')
out={};counts=Counter();expected=set()
for (cls,sp),f in profiles.items():
 d=obs['profiles'][f]
 for slot,entries in d['modes'].items():
  for i,modes in entries.items():
   for mode in modes:
    key=(cls,sp,mode,slot,int(i));expected.add(key)
    if key not in keys:continue
    st,phase,rank=d['status'][slot][i];sides=set(d['sides'][slot][i]) & keys[key]
    prefix='Contrôle sur boss · ' if mode=='pvp' else ''
    if st in ('unknown_source','legacy_unsold'):
     prefix+='projection, obtention non vérifiée'+(' (ancienne récompense de rang)' if st=='legacy_unsold' else '')+' · '
    elif st=='future':
     gates=[]
     if phase:gates.append('phase 1' if phase==1 else 'phase ultérieure')
     if rank>6:gates.append(f'rang {rank}')
     prefix+='projection, '+', '.join(gates)+' · '
    if st in ('absent','suffix'):value='ID absent des deux bases WoWSims' if st=='absent' else 'suffixe aléatoire indéterminé'
    else:
     if not sides:raise ValueError(('No documented faction for current row',key))
     vals=[]
     for s,name in [('a','Alliance'),('h','Horde')]:
      if s not in sides:continue
      row=d['factions'][s]['items'][slot][i]
      if f=='cat':z=f'{n(row[0],True)} ± {n(row[1])} DPS'
      else:z=f'{n(row[2],True)} ± {n(row[5])} menace/s, {n(row[3],True)} ± {n(row[6])} dégâts reçus/s'
      vals.append(name+' '+z)
     value=' / '.join(vals)
     if keys[key]-sides:value+=' · '+('voie Horde non vérifiée' if 'h' not in sides else 'voie Alliance non vérifiée')
     if int(i) in d['effects_missing']:value+=' · effet omis'
     if int(i) in d['assumed_rate']:value+=' · fréquence de proc supposée'
    out['/'.join(map(str,key))]=prefix+value;counts[mode,st]+=1
assert set(keys)==expected,(set(keys)-expected,expected-set(keys))
args.output.write_text(json.dumps(out,ensure_ascii=False,separators=(',',':')),encoding='utf8');print(len(out),counts)
