"""Read actual faction IDs, restricting every proposed item to the sides where its token makes it visible."""
from collections import defaultdict
from pathlib import Path
import hashlib,json,re
P=Path(__file__).resolve().parent;path=Path.cwd()/'Data/Lists.lua'
names={('DRUID','4'):'cat',('DRUID','2'):'bear',('WARRIOR','3'):'war',('PALADIN','2'):'pal'}
slots=defaultdict(lambda:defaultdict(lambda:defaultdict(dict)))
for line in path.read_text(encoding='utf8').splitlines():
 if m:=re.match(r'^([A-Z]+) = \[==\[',line):cls=m[1]
 if not line.startswith('L\t'):continue
 _,sp,mode,slot,tokens=line.split('\t');f=names.get((cls,sp))
 if not f:continue
 for t in tokens.split():
  i,_,flags,twin,*rest=(t+':'*5).split(':');side=next((s for s in 'ah' if s in flags),'ah')
  for id,s in [(i,side)]+([(twin,{'a':'h','h':'a'}[side])] if twin else []):d=slots[f][slot][id];d[mode]=''.join(sorted(set(d.get(mode,'')+s)))
p=P/'catalogue.json';p.write_text(json.dumps({'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'rows':slots},separators=(',',':')),encoding='utf8')
old=json.loads((P/'initial-results.json').read_text());new={(f,sl,i) for f,ss in slots.items() for sl,values in ss.items() for i in values};prev={(f,sl,i) for f,ss in old['profiles'].items() for sl,values in ss['modes'].items() for i in values}
print('distinct old/new',len(prev),len(new),'added',sorted(new-prev),'removed',sorted(prev-new))
