"""Verify the catalogue, faction eligibility and every saved configuration, then assemble the numerical report."""
import argparse, collections, hashlib, json, math, os, re, statistics, subprocess
from pathlib import Path
P=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf8')
parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,default=Path.cwd());parser.add_argument('--output',type=Path,default=P/'results.json');parser.add_argument('--engine',type=Path,default=Path(os.environ.get('WOWSIMS_CHECKOUT',str(P.parent/'easybis-upstream-a73af714'/'forever-a73af7145111ce19c621e3b5f678553adf326907'))));args=parser.parse_args()
legal=read(P/'legality.json');old=read(P/'initial-results.json');plans=[read(P/'plan.json'),read(P/'plan-conditional.json')];folders=['groups','groups-conditional']
names={'cat':('DRUID','4'),'bear':('DRUID','2'),'war':('WARRIOR','3'),'pal':('PALADIN','2')};translate={v:k for k,v in names.items()}
catalogue=collections.defaultdict(lambda:collections.defaultdict(lambda:collections.defaultdict(set))); path=args.root/'Data/Lists.lua'
for line in path.read_text(encoding='utf8').splitlines():
 if m:=re.match(r'^([A-Z]+) = \[==\[',line):cls=m[1]
 if not line.startswith('L\t'):continue
 _,spec,mode,slot,tokens=line.split('\t');f=translate.get((cls,spec))
 if not f:continue
 for token in tokens.split():
  bits=token.split(':')+['']*6;i,flags,twin=bits[0],bits[2],bits[3]
  side='a' if 'a' in flags else 'h' if 'h' in flags else 'ah'
  catalogue[f][slot][i].add((mode,side))
  if twin:catalogue[f][slot][twin].add((mode,{'a':'h','h':'a'}[side]))
data={k:old[k] for k in ('engine','binary_sha256','iterations','seed','duration_seconds','duration_variation','columns','shield_corrections','stock_shield_columns')}
data.update(catalogue_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),current_max_honor_rank=6,current_phase=0,profiles={},counts={})
data['side_evidence']={k:v['side_basis'] for k,v in legal['facts'].items() if v.get('side_basis')}
data['status_codes']={'current':'voie pré-raid documentée, dans le plafond hebdomadaire','future':'phase ou rang supérieur au cap au 22 novembre 2026','legacy_unsold':'projection : ancienne récompense de rang sans vente Forever établie','unknown_source':'projection : obtention individuelle non vérifiée','absent':'ID absent des deux bases WoWSims','suffix':'suffixe aléatoire requis'}
expected=read(P/'catalogue.json');assert data['catalogue_sha256']==expected['sha256']
mainitems={i['id'] for i in read(args.engine/'assets/database/db.json')['items']}
native={i['id']:i for filename in ('db.json','leftover_db.json') for i in read(args.engine/'assets/database'/filename)['items']}
all_ids={int(i) for slots in catalogue.values() for entries in slots.values() for i in entries}
effect_ids={i for i in all_ids if native.get(i,{}).get('itemEffects')};save(P/'effect-ids.json',sorted(effect_ids))
effect_status=json.loads(subprocess.check_output([str(P/'runner.exe'),'effects',str(P/'effect-ids.json')]));no_effect={int(i) for i,v in effect_status.items() if not v} | {15866}  # game spell 19634 is absent from both native item definitions
groups={}; cases=collections.Counter();differences={};overall=collections.Counter()
for f,slots in catalogue.items():
 b=old['profiles'][f];specids={int(i) for entries in slots.values() for i in entries};meta={'modes':{},'catalogue_sides':{},'sides':{},'status':{},'factions':{},'effects_missing':sorted(specids & no_effect),'assumed_rate':sorted(specids & {1728,11750,14555}),'source_leftover':{slot:sorted(int(i) for i in entries if int(i) in native and int(i) not in mainitems) for slot,entries in slots.items()}}
 for side in 'ah':
  rr=legal['profiles'][f][side];meta['factions'][side]={'race':rr['race'],'gear':rr['gear'],'enchants':rr['enchants'],'items':{},'stock_minus_corrected_shield':{},'direct':{}}
 for slot,entries in slots.items():
  for k in ('modes','catalogue_sides','status','sides'):meta[k][slot]={}
  for sd in 'ah':meta['factions'][sd]['items'][slot]={}
  for i,mm in entries.items():
   raw=legal['facts'][i]; modes=sorted(set(m for m,s in mm));sc=''.join(sorted(set(''.join(s for m,s in mm))))
   assert set(modes)==set(expected['rows'][f][slot][i]);meta['modes'][slot][i]=modes;meta['catalogue_sides'][slot][i]=sc
   scores={};reasons=[];status=set()
   for s in 'ah':
    k=f'{f}/{s}/{slot}/{i}';hits=[j for j,plan in enumerate(plans) if k in plan['cases']]
    if not hits:reasons.append(plans[0]['exclusions'][k]);continue
    if s not in sc:continue
    assert len(hits)==1 and s in raw['sides']
    j=hits[0];tag,ref=plans[j]['cases'][k];filename=P/folders[j]/(tag+'.json');inp=P/folders[j]/(tag+'.input.json')
    if filename not in groups:groups[filename]=(read(filename),{v['key']:v for v in read(inp)['jobs']})
    vals,jobs=groups[filename];assert ref in vals and ref in jobs and jobs[i]['RefKey']==ref
    a=jobs[ref]['gear'];bgear=jobs[i]['gear'];assert all(ai==bi or (bi['id']==int(i) and ai['id']==0) for ai,bi in zip(a,bgear)) and sum(ai!=bi for ai,bi in zip(a,bgear))==1
    v=vals[i];assert len(v)==7 and all(math.isfinite(x) for x in v) and min(v[k] for k in (1,5,6))>=0
    scores[s]=v;meta['factions'][s]['items'][slot][i]=v
    if 'stock-'+i in vals:meta['factions'][s]['stock_minus_corrected_shield'][i]=vals['stock-'+i]
    st=plans[0]['exclusions'][k] if j else 'future' if raw['phase']>0 or raw['rank']>6 else 'current';status.add(st);cases[f,s,st]+=1
   if scores:
    assert len(status)==1,(f,slot,i,status);st=status.pop()
   else:
    assert set(reasons)&{'absent','suffix'},(f,slot,i,reasons,sc);st=next(v for v in reasons if v in ('absent','suffix'))
   meta['status'][slot][i]=[st,raw['phase'],raw['rank']];meta['sides'][slot][i]=''.join(scores);overall[f,st]+=1
 for side,d in meta['factions'].items():
  for tag in plans[0]['checks']:
   if tag.startswith(f'direct-{f}-{side}-'):d['direct'][tag.split('-',3)[3]]=read(P/'groups'/(tag+'.json'))
 assert set(meta['modes'])==set(expected['rows'][f]) and all(set(v)==set(expected['rows'][f][slot]) for slot,v in meta['modes'].items())
 data['profiles'][f]=meta
 side='a' if f=='pal' else 'h';delta=[]
 for slot,entries in meta['factions'][side]['items'].items():
  for i,v in entries.items():
   prev=b['items'][slot].get(i)
   if not prev:continue
   delta.append([slot,int(i),*[round(v[j]-prev[j],4) for j in (0,2,3)]])
 differences[f]={'side':side,'count':len(delta),'median_abs':[round(statistics.median(abs(row[j]) for row in delta),3) for j in (2,3,4)],'maxima':[max(delta,key=lambda row:abs(row[j])) for j in (2,3,4)]}
data['counts']={f:{st:overall[f,st] for st in data['status_codes']} for f in names}
data['side_counts']={f:{s:{st:cases[f,s,st] for st in data['status_codes'] if cases[f,s,st]} for s in 'ah'} for f in names}
data['differences_first_pass_same_side']=differences
save(args.output,data);print(json.dumps(data['counts']));print(json.dumps(data['side_counts']));print(json.dumps(differences))
