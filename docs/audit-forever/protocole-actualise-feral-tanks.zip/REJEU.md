# Rejouer les huit références et les substitutions du félin et des trois tanks

La campagne utilise le commit [a73af7145111ce19c621e3b5f678553adf326907 de WoWSims Forever](https://github.com/wowsims/forever/tree/a73af7145111ce19c621e3b5f678553adf326907) avec les deux bases embarquées. Les objets, emplacements, modes et camps du catalogue final sont figés dans `catalogue.json`. Les huit références corrigées, les races, les effets d’enchantement et les critères de vérification sont dans `legality.json`. Les sept colonnes numériques du résultat sont décrites dans `columns`. L’archive contient le code du pilote sans exécutable.

1. Extraire ce ZIP. Compiler le pilote dans un checkout du commit indiqué, avec les protobuf Go requis par le projet. La cible upstream `make sim/core/proto/api.pb.go` les génère si nécessaire. Adapter les trois chemins aux dossiers locaux.

```powershell
$protocole = 'C:/audit/protocole'
$wow = 'C:/audit/forever-a73af7145111ce19c621e3b5f678553adf326907'
$addon = 'C:/audit/EasyBIS'
Set-Location -LiteralPath $wow
$env:CGO_ENABLED = '0'
$env:GOARCH = 'amd64'
go build -tags=with_db -o "$protocole/runner.exe" "$protocole/runner/main.go" "$protocole/runner/check.go" "$protocole/runner/effects.go"
```

2. Lancer les substitutions dont la source est documentée et les projections d’obtention incertaine, puis vérifier les sorties. Le réglage `--workers` donne le nombre de groupes conduits simultanément. `--cpu` fixe GOMAXPROCS pour chaque processus Go. Chaque groupe achevé conserve son entrée et ses résultats appariés dans `groups` ou `groups-conditional`. Une reprise valide à nouveau les configurations et les groupes présents. Le dupliqué PvE/JcJ conserve sa mesure sur boss.

```powershell
Set-Location -LiteralPath $addon
python "$protocole/replay_legal.py" --engine $wow --workers 2 --cpu 8
python "$protocole/replay_legal.py" --engine $wow --workers 2 --cpu 8 --theoretical
python "$protocole/collect_legal.py" --root $addon --output "$protocole/results.json"
python "$protocole/register_cells.py" $addon --results "$protocole/results.json" --output "$protocole/cellules.json"
```

3. Pour reconstituer les données d’éligibilité, `tooltip-sha256.json` contient les empreintes des 1 265 fiches individuelles Forever du service Wowhead (`dataEnv=16`). Le script `fetch.py` les télécharge pour une nouvelle lecture des conditions du client. La liste des sources WoWSims et celles de ForeverDB corrigée, les exigences de métiers, les ensembles et la restriction de faction retenue sont dans `legality.json`. `catalogue-side-review.json` conserve les 58 cas examinés **avant les corrections de faction du catalogue**. Chaque entrée indique le niveau de preuve. `side-evidence.json` fige les décisions de la campagne. Depuis la même version du dépôt EasyBIS et du snapshot ForeverDB, la commande ci-dessous régénère les huit références. La reconstruction n’est pas nécessaire pour rejouer les calculs archivés.

```powershell
$env:WOWSIMS_CHECKOUT = $wow
python "$protocole/fetch.py"
python "$protocole/prepare_legal.py"
```

Le fichier `initial-results.json` contient la première campagne complète, qui utilisait notamment les épaules de Theramore sur deux taurens. `initial-references.json` conserve ses quatre tenues. Le protocole de ce premier passage et les témoins intermédiaires du guerrier avec ses anciens rangs de sorts sont dans `archive`. Ils documentent l’effet de la correction. Le champ `differences_first_pass_same_side` du nouveau résultat compare les deltas sur le même camp. Les changements d’équipement, d’enchantement et de rang de sort peuvent se cumuler.

Les différences statistiques sont appariées, avec une même graine pour chaque porteur et témoin. Employer les mêmes résultats au lieu de les recalculer demande de reprendre la base, les métiers, la liste d’actions, les activations et les deux configurations exactes. Les fichiers de cette archive fournissent ces entrées.

Les empreintes canoniques des 257 sorties sont dans `group-results-sha256.json`. Elles portent sur le JSON encodé en UTF-8, avec clés triées, valeurs Unicode conservées et sans espaces.
