from pathlib import Path
from collections import Counter
import os,json
P=Path(__file__).resolve().parent
D=json.loads((P/'results.json').read_text(encoding='utf8'));L=json.loads((P/'legality.json').read_text());names={'cat':('Félin','druid-feral-cat'),'bear':('Ours','druid-feral-bear'),'war':('Guerrier Protection','warrior-protection'),'pal':('Paladin Protection','paladin-protection')};profiles=D['profiles']
def n(x,s=False,digits=2):return ('+' if s and x>0 else '')+f'{x:.{digits}f}'.replace('-','−').replace('.',',')
def pm(row,ind,se,d=2):return n(row[ind],True,d)+' ± '+n(row[se],False,d)
def tank(row):return pm(row,2,5)+' / '+pm(row,3,6)
def link(f):label,fn=names[f];return f'[{label}]({fn}.md)'
pieces=sum((Counter(v) for v in D['counts'].values()),Counter());total=sum(pieces.values());skip=pieces['absent']+pieces['suffix'];measured=total-skip
sidecount=sum(sum(cs.values()) for s in D['side_counts'].values() for cs in s.values());rows=Counter();fx=Counter()
for f,r in profiles.items():
 for slot,entries in r['modes'].items():
  for i,ms in entries.items():
   st=r['status'][slot][i][0];rows.update((mode,st) for mode in ms)
   if st not in ('absent','suffix'):fx['missing']+=int(int(i) in r['effects_missing']);fx['assumed']+=int(int(i) in r['assumed_rate'])
def lines(mode):return sum(c for (m,s),c in rows.items() if m==mode)
def simlines(mode):return sum(c for (m,s),c in rows.items() if m==mode and s not in ('absent','suffix'))
out=[]
def a(x=''):out.append(x)
a('# Félin et tanks · WoWSims Forever sur huit tenues de référence')
a()
a(f'Au 22 novembre 2026, **{measured:,} des {total:,} propositions distinctes** du félin et des trois tanks ont une mesure sur le moteur `a73af71451`. **{pieces["current"]:,}** ont une voie d’obtention documentée dans les limites pré-raid et de rang de la semaine. **{pieces["future"]}** relèvent d’une phase ultérieure ou d’un rang supérieur. Pour **{pieces["legacy_unsold"]+pieces["unknown_source"]}** autres, la valeur est une projection sur une tenue vérifiée, l’obtention de la pièce restant incertaine. Les factions ont été simulées séparément sur une race et une tenue propres à chacune. [Révision de WoWSims](https://github.com/wowsims/forever/commit/a73af7145111ce19c621e3b5f678553adf326907) · [Données chiffrées](controle-actualise-feral-tanks.json)'.replace(f'{measured:,}',f'{measured:,}'.replace(',',' ')).replace(f'{total:,}',f'{total:,}'.replace(',',' ')).replace(f'{pieces["current"]:,}',f'{pieces["current"]:,}'.replace(',',' ')))
a();a('## Couverture et disponibilité');a()
a('| Profil | Pré-raid et rang atteint | Phase ou rang ultérieur | Ancien rang sans vendeur Forever | Obtention non vérifiée | ID absent | Suffixe indéterminé | Total |');a('|---|---:|---:|---:|---:|---:|---:|---:|')
for f,c in [*D['counts'].items(),('total',pieces)]:
 a('| '+' | '.join([link(f) if f!='total' else '**Total**',*map(str,[c[k] for k in ('current','future','legacy_unsold','unknown_source','absent','suffix')]),str(sum(c.values()))])+' |')
a();a(f'Les fiches du [registre](README.md) contiennent {simlines("pve")} valeurs pour {lines("pve")} lignes PvE et {simlines("pvp")} pour {lines("pvp")} lignes JcJ. Un même ID peut appartenir aux deux modes. Le total numérique couvre {sidecount} substitutions **spécialisation × emplacement × ID × faction**. Pour les lignes JcJ, « contrôle sur boss » rappelle que la mesure décrit un combat de raid. La robustesse, le contrôle, l’endurance et les adversaires joueurs relèvent du classement JcJ de l’addon.')
a();a(f'Les deux bases officielles du moteur sont chargées. {pieces["absent"]} propositions restent sans définition WoWSims et {pieces["suffix"]} demanderaient de connaître le suffixe aléatoire. Parmi les valeurs numériques, {fx["missing"]} incluent un effet absent du moteur et {fx["assumed"]} utilisent une fréquence de proc supposée. Les cellules portent la réserve correspondante. [Chargeur WoWSims](https://github.com/wowsims/forever/blob/a73af7145111ce19c621e3b5f678553adf326907/assets/database/loader.go)')
a();a(f'Le catalogue final a pour SHA-256 `{D["catalogue_sha256"]}`. Le contrôle associe chaque ligne à son véritable ID, y compris lorsqu’EasyBIS affiche un jumeau de faction. Le code de phase 9 regroupe les phases ultérieures ou dont la date reste indéterminée. Le plafond retenu pour la semaine est le rang 6. [Progression JcJ de Blizzard](https://worldofwarcraft.blizzard.com/en-us/news/24303316) · [Rangs d’EasyBIS](../../_build/ranks.py) · [Phases d’EasyBIS](../../_build/phases.py)')
a();a('## Références corrigées');a()
a('Chaque tenue de contrôle a été vérifiée au niveau 60 pour sa classe, sa faction, ses conditions d’équipement et une source compatible avec la phase. Les profils sont elfe de la nuit et tauren pour les druides, humain et orc pour le guerrier, humain et réprouvé pour le paladin. Les essais vérifient chaque objet, ses conditions de métier, son type d’armure ou d’arme, les autres emplacements occupés, l’unicité et les récompenses de quête incompatibles. Les enchantements conservés ont une formule ou une quête identifiée et un emplacement compatible. [Capacités des classes](https://github.com/wowsims/forever/blob/a73af7145111ce19c621e3b5f678553adf326907/ui/sim/player/classes/capabilities_auto_gen.ts) · [Sources des objets, entrées et vérifications](protocole-actualise-feral-tanks.zip)')
a()
a('| Profil | Corrections apportées à la première tenue |');a('|---|---|')
a('| Félin | Theramore Pauldrons (271955) sur l’elfe et Darkspear Pauldrons (272105) sur le tauren. Le félin porte Blackhand’s Breadth (13965) avec Mark of the Chosen (17774, Alliance) ou Rune of the Guard Captain (19120, Horde). La formule pré-raid appropriée aux gants pour l’effet 2564 reste à confirmer. Les gants sont testés sans cet enchantement. |')
a('| Ours | Même distinction pour les épaules. Les jambes et l’insigne d’Alterac ont des ID propres à chaque camp. Les brassards, bottes, bagues et arme de rang ou de raid sont remplacés. L’arme de base est The Unstoppable Force (19323), récompense de réputation d’Alterac. Le « rang 6 » qui figure dans le nom de l’insigne désigne son étape de réputation. |')
a('| Guerrier | Mark of Fordring (15411) et Boots of Valor (16734) remplacent deux objets à source incertaine dans les archives. Le bouclier de base porte zéro enchantement pour l’effet 7663, dont la formule appropriée restait incertaine. Le guerrier emploie les rangs du maître pour Cri de guerre (11551), Vengeance (11601) et Frappe héroïque (11567). |')
a('| Paladin | Le collier est Mark of Fordring, les épaules Lightforge Spaulders (16729), l’arme Thrash Blade (17705) et le bouclier Draconian Deflector (12602). Le logement de libram reste vide. L’ancienne tenue comportait notamment une arme de progression de raid et des épaules de faction. |')
a();a('Les épaules Theramore et Darkspear ont chacune leur réputation dans les infobulles Forever. Pour les ensembles bleus Premier, la vérification distingue les vendeurs retrouvés pour l’ID exact, l’appartenance à un ensemble et les ressemblances de famille. Une attribution par ensemble seule conserve la mention « projection, obtention non vérifiée ». Les cinq quêtes historiques du set Avenger’s ont un côté Alliance dans les données disponibles. La campagne garde une projection de phase Alliance pour ces cinq pièces. [Épaules Theramore](https://www.wowhead.com/forever/item=271955) · [Épaules Darkspear](https://www.wowhead.com/forever/item=272105) · [Fiche du vendeur des épaules Chevalier](https://raiddex.com/en/wow-forever/items/premier-chevalier-shoulders)')
a();a('## Protocole et incertitude');a()
a('Chaque valeur donne l’effet de la pièce face à l’emplacement vide, sur 2 000 combats de 180 secondes avec une variation de 5 secondes et la graine 4242. Les bagues et bijoux partent de deux emplacements vides. Une arme à deux mains libère la main gauche. Le druide évaluant une main gauche tient la masse à une main 11923. L’enchantement 1896, réservé aux armes à deux mains, est retiré sur les armes à une main. Une pièce exigeant un métier est essayée par un personnage qui le possède. Les deux configurations de la comparaison ont les mêmes métiers. [Pilote, huit profils et recettes de rejeu](protocole-actualise-feral-tanks.zip)')
a();a('Le signe **±** donne une erreur standard de la différence appariée entre deux configurations à graine identique. Une différence voisine de deux erreurs standard mérite un contrôle supplémentaire. Les écarts de deux pièces face à un emplacement vide ne fournissent pas à eux seuls l’erreur de leur duel direct. Un signe positif signifie plus de dégâts infligés, plus de menace ou plus de dégâts reçus selon la colonne. Les deux tanks à bouclier et l’ours font face au boss. Les réserves sur les effets, la rotation et les buffs de la rencontre restent applicables aux deux factions.')
a();a('## Félin · duels directs à 20 000 combats');a()
a('| Remplacement, deuxième configuration moins première | Alliance · Δ DPS ± ES | Horde · Δ DPS ± ES |');a('|---|---:|---:|')
for sl,k,title in [('off','Scepter','Tome of Knowledge → Scepter of Interminable Focus'),('main','Bonecrusher','Legionite Glaive → Bonecrusher'),('head','Eye','Outlaw’s Collar → Eye of Rend'),('head','Wolfshead','Outlaw’s Collar → Wolfshead Helm'),('back','Howler','Blackveil Cape → Howler’s Furs'),('finger','Warden','Cutthroat’s Signet → Warden’s Signet of Ferocity'),('trinket','passive','Emplacement vide → Behemoth Bones, soin laissé hors rotation'),('trinket','activation','Emplacement vide → Behemoth Bones, soin forcé'),('trinket-supplement','Lucky non forcé','Behemoth Bones passif → Lucky Shovelnose Tuft, activation laissée à la rotation'),('trinket-supplement','Lucky forcé','Behemoth Bones passif → Lucky Shovelnose Tuft, activation forcée')]:
 a('| '+title+' | '+' | '.join(pm(profiles['cat']['factions'][side]['direct'][sl][k],0,1,3) for side in 'ah')+' |')
a();a('Le gain du Scepter et celui de Legionite Glaive sont résolus sur les deux tenues. Howler’s Furs perd du DPS dans cette rotation. L’écart sur le tauren atteint tout juste deux erreurs standard, contre plus de dix sur la référence elfe. Forcer le soin de Behemoth Bones coûte du DPS aux deux races. L’activation forcée de Lucky Shovelnose Tuft face à Behemoth Bones passif demeure indécidable pour la référence Alliance. [Fiche félin](druid-feral-cat.md)')
a();a('## Ours · menace et dégâts reçus');a()
a('| Bijou face à un emplacement vide | Alliance · Δ menace/s / Δ dégâts reçus/s | Horde · Δ menace/s / Δ dégâts reçus/s |');a('|---|---:|---:|')
for i in ('272437','272440'):
 a('| '+L['facts'][i]['name']+' | '+' | '.join(tank(profiles['bear']['factions'][side]['items']['trinket'][i]) for side in 'ah')+' |')
a();a('Adaptive Combat Assistant augmente nettement la menace dans les deux configurations. Defender’s Grip Stabilizer réduit davantage les dégâts reçus. Leurs erreurs standard individuelles ne mesurent pas l’incertitude de la différence entre ces deux bijoux. [Fiche ours](druid-feral-bear.md)')
a();a('## Boucliers · duels directs à 2 000 combats');a()
a('Chaque ligne oppose le bouclier corrigé au **Draconian Deflector**. Pour Force Reactive Disk, la projection suppose un porteur avec Ingénierie 300 et l’accès futur à la pièce. La valeur de blocage intrinsèque est corrigée à partir des données du client dans les deux configurations. [Valeurs du client](../../_build/corrections/shields.json)')
a();a('| Bouclier | Porteur | Alliance · Δ menace/s / Δ dégâts reçus/s | Horde · Δ menace/s / Δ dégâts reçus/s |');a('|---|---|---:|---:|')
for i in ('279262','18168','18499'):
 for f in ('war','pal'):a('| '+L['facts'][i]['name']+' | '+names[f][0]+' | '+' | '.join(tank(profiles[f]['factions'][s]['direct']['shields'][i]) for s in 'ah')+' |')
a();a('Evergreen Shield augmente la menace et réduit les dégâts reçus sur les quatre porteurs. Sur le paladin réprouvé, son avantage de mitigation se situe à la limite de deux erreurs standard. La différence de dégâts reçus entre Barrier Shield et Draconian Deflector reste incertaine dans ces quatre duels. [Fiche guerrier](warrior-protection.md) · [Fiche paladin](paladin-protection.md)')
a();a('Pour Evergreen Shield, le moteur brut applique 58 de blocage alors que l’infobulle Forever indique 44. Les témoins suivants portent exactement le même objet et conservent la même tenue. La seule variation est la correction de ces 14 points. Les valeurs donnent le résultat corrigé moins le moteur brut.')
a();a('| Porteur · Evergreen Shield corrigé | Alliance · Δ menace/s / Δ dégâts reçus/s | Horde · Δ menace/s / Δ dégâts reçus/s |');a('|---|---:|---:|')
for f in ('war','pal'):
 vals=[]
 for side in 'ah':
  z=profiles[f]['factions'][side]['stock_minus_corrected_shield']['279262'].copy();z[2]*=-1;z[3]*=-1;vals.append(tank(z))
 a('| '+names[f][0]+' | '+' | '.join(vals)+' |')
a();a('## Variation causée par la correction des références');a()
a('La première campagne complète de la même révision utilisait une seule race par profil. Le tableau compare les valeurs de substitution de ce premier passage à celles du même camp sur la nouvelle tenue. Il donne la médiane des variations absolues et le cas le plus éloigné sur chaque critère applicable. Ces écarts regroupent les changements simultanés de tenue, d’enchantement et, pour le guerrier, de rangs de sorts. Les témoins à équipement identique isolent la correction du blocage. [Première campagne et témoins archivés](protocole-actualise-feral-tanks.zip)')
a();a('| Profil · camp de départ | Cas communs | Critère | Variation absolue médiane | Plus grande variation signée |');a('|---|---:|---|---:|---|')
for f,de in D['differences_first_pass_same_side'].items():
 for k,what in ([(0,'DPS')] if f=='cat' else [(1,'menace/s'),(2,'dégâts reçus/s')]):
  entry=de['maxima'][k];a('| '+names[f][0]+' · '+('Alliance' if de['side']=='a' else 'Horde')+' | '+str(de['count'])+' | '+what+' | '+n(de['median_abs'][k],False,3)+' | '+n(entry[k+2],True,3)+' · '+L['facts'][str(entry[1])]['name']+' ('+str(entry[1])+') |')
a();a('Les projections de faction, les mesures de survie sur boss et les poids de classement répondent à des questions différentes. Les deux colonnes de tank et les duels directs permettent de repérer un choix de menace ou de mitigation même lorsque l’ordre du score statique ne les départage pas. [Registre détaillé](README.md)')
(P/'report.md').write_text('\n'.join(out)+'\n',encoding='utf8')
