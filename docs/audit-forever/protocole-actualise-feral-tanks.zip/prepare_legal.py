from pathlib import Path
import json,os,sys,re,html,collections,copy,hashlib
p=Path(__file__).resolve().parent
root=Path.cwd();sys.path.insert(0,str(root/'_build'))
import fdb,phases,ranks
ld=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
def write(name,data):(p/name).write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')),encoding='utf8')
db=fdb.load(root/'_build/cache/ForeverDB')
engdir=Path(os.environ.get('WOWSIMS_CHECKOUT',str(p.parent/'easybis-upstream-a73af714'/'forever-a73af7145111ce19c621e3b5f678553adf326907')))
books=[ld(engdir/'assets/database'/f) for f in ('db.json','leftover_db.json')]
eng={x['id']:x for b in books for x in b['items']}
ench=collections.defaultdict(list)
for b in books:
 for e in b['enchants']:ench[e['effectId']].append(e)
m=ld(p/'initial-results.json');presets=ld(p/'initial-references.json')
cls={'cat':'DRUID','bear':'DRUID','war':'WARRIOR','pal':'PALADIN'}
cn={'cat':11,'bear':11,'war':1,'pal':2}
nums={'cat':4,'bear':2,'war':3,'pal':2}
races={'cat':('RaceNightElf','RaceTauren'),'bear':('RaceNightElf','RaceTauren'),'war':('RaceHuman','RaceOrc'),'pal':('RaceHuman','RaceUndead')}
forms={};candidates={};facts={};enchants={};tipdir=p/'tooltips'
slots=['head','neck','shoulder','back','chest','wrist','hands','waist','legs','feet','finger','finger','trinket','trinket','main','off','ranged']
sides={'a','h'}
rep_a=('Silverwing Sentinels','Stormpike Guard','Theramore Expeditionary Force','The League of Arathor')
rep_h=('Warsong Outriders','Frostwolf Clan','Darkspear Raiders','The Defilers')
def fside(n):return {1:'a',2:'h'}.get(n,'')
def sideof_source(kind,row):
 if kind=='rep':return fside(row.get('factionId')) or ({2799:'a',2798:'h',509:'a',510:'h',729:'h',730:'a',889:'h',890:'a'}.get(row.get('repFactionId'),''))
 return fside(row.get('faction'))
side_notes=ld(p/"side-evidence.json")
tooltip_missing=[]
def inspect(i):
 if i in facts:return facts[i]
 native=eng.get(i,{})
 item=db.items.get(i,{});gear=db.gear.get(i,{})
 tip=ld(tipdir/f'{i}.json') if (tipdir/f'{i}.json').exists() else {}
 desc=html.unescape(' '.join(re.sub(r'<[^>]+>',' ',tip.get('tooltip','')).split()))
 if not tip.get('name'):tooltip_missing.append(i)
 reps=sorted(set(re.findall(r'Requires ([^<]*?) - (?:Friendly|Honored|Revered|Exalted)',desc)))
 st=set()
 if any(re.search('Requires '+r+r' - ',desc) for r in rep_a):st.add('a')
 if any(re.search('Requires '+r+r' - ',desc) for r in rep_h):st.add('h')
 acc=set(sides);reach=set();evidence=[];quests=set();onlyquest=True
 for fact in [fside(native.get('factionRestriction')),item.get('side')]:
  if fact:acc&={fact}
 if st:acc&=st
 for src in native.get('sources',[]):
  k,row=next(iter(src.items()))
  who=sideof_source(k,row)
  # An undocumented vanilla PvP vendor does not establish the sale of a historical piece in Forever.
  reach.update(who or 'ah');evidence.append([k,row])
  if k=='quest':quests.add(row['id'])
  else:onlyquest=False
 for kind,*rest in item.get('sources',[]):
  if kind=='q': who=rest[3] if len(rest)>3 and rest[3] in ('a','h') else '';quests.add(int(rest[0]))
  elif kind=='V':who=rest[2] if len(rest)>2 and rest[2] in ('a','h') else ''
  elif kind=='v':who=rest[6] if len(rest)>6 and rest[6] in ('a','h') else ''
  elif kind=='p':who=rest[1] if len(rest)>1 and rest[1] in ('a','h') else ''
  elif kind=='r':who={2799:'a',2798:'h',509:'a',510:'h',729:'h',730:'a',889:'h',890:'a'}.get(int(rest[0]),'')
  else:who=''
  if kind!='q':onlyquest=False
  # Prefer native faction-specific source information to a condensed ForeverDB row which dropped the side.
  if not evidence or who:reach.update(who or 'ah')
 if ranks.sold_for_honor(item) if item else False:reach.update(acc)
 if reach:acc&=reach
 extra=side_notes.get(str(i),{})
 if extra:
  acc&=set(extra['side'])
  if extra['evidence'].startswith(('famille','attribution')):reach.clear()
 prof={x for x in re.findall(r'Requires (Engineering|Leatherworking|Blacksmithing|Tailoring|Alchemy|Enchanting|Mining|Skinning|Herbalism)(?:\s*\(|\b)',desc)}
 if native.get('requiredProfession'):prof.add({2:'Blacksmithing',3:'Enchanting',4:'Engineering',8:'Leatherworking',11:'Tailoring'}[native['requiredProfession']])
 tc=re.search(r'Classes: (.*?)(?: Requires| Equip:| Use:| Item Level|$)',desc)
 tipcls=sorted(set(re.findall(r'\b(Warrior|Druid|Paladin|Rogue|Mage|Priest|Hunter|Shaman|Warlock)\b',tc[1]))) if tc else []
 faction_mask=re.search(r'Races: (.*?)(?: Requires| Equip:| Use:|$)',desc)
 facts[i]={'name':native.get('name') or item.get('name') or str(i),'sides':''.join(sorted(acc)),'known_source':bool(reach),'side_basis':extra,'source_wowsims':evidence,'source_foreverdb':item.get('sources',[]),'phase':phases.item_phase(item) if item else 0,'rank':ranks.required(item,gear) if item else 0,'prof':sorted(prof),'tip_classes':tipcls,'tip_races':faction_mask[1] if faction_mask else '', 'set':native.get('setId',0),'quest_only':sorted(quests) if onlyquest else [],'tip':bool(tip.get('name'))}
 return facts[i]
# Confirmed pre-raid/weekly-rank-6 reference substitutions. No pets or faction/racial actives are added.
for f,old in presets.items():
 forms[f]={}
 for si,side in enumerate(('a','h')):
  ref=list(old['gear']);effects=list(old['enchants'])
  fixes={
   'cat':{2:271955 if side=='a' else 272105,12:17774 if side=='a' else 19120,13:13965},
   'bear':{2:271955 if side=='a' else 272105,5:18375,8:22749 if side=='a' else 22740,9:12553,10:19325,11:17713,12:17904 if side=='a' else 17909,13:13965 if side=='a' else 19120,14:19323},
   'war':{1:15411,9:16734},
   'pal':{1:15411,2:16729,14:17705,15:12602,16:0}
  }[f]
  for seat,i in fixes.items():ref[seat]=i
  # Skip glove 2564 and shield 7663: no verifiable matching pre-raid formula in the reference inputs.
  if f=='cat':effects[6]=0
  if f=='war':effects[15]=0
  base=copy.deepcopy(old['base']);player=base['raid']['parties'][0]['players'][0];player['race']=races[f][si]
  player.pop('equipment',None)
  if f=='war':player['rotation']=ld(engdir/'ui/specs/warrior/protection/apls/default.apl.json')
  forms[f][side]={'race':player['race'],'gear':ref,'enchants':effects,'base':base}
  for pos,i in enumerate(ref):
   if not i:continue
   attr=inspect(i);assert side in attr['sides'] and attr['known_source'] and attr['phase']==0 and attr['rank']<=6,(f,side,pos,i,attr)
  for e in set(effects)-{0}:enchants[e]=ench[e]
for old in presets.values():
 for i in old['gear']:
  if i:inspect(i)
 for e in set(old['enchants'])-{0}:enchants[e]=ench[e]
for ss in ld(p/'catalogue.json')['rows'].values():
 for entries in ss.values():
  for i in entries:inspect(int(i))
for f,profile in m['profiles'].items():
 for sl,rows in profile['modes'].items():
  for iid in rows:inspect(int(iid))
for i in [11923,8345,11626,272414,272408,275981,13385,22329,250619,18420,279253,12587,280065,280060,12602,18168,18499,279262]:inspect(i)
# Source support for cat comparisons: the Warbear's confirmed loot quest/class is checked with each job.
write('legality.json',{'facts':facts,'enchants':enchants,'profiles':forms,'classes':cn,'slots':slots,'missing_tooltips':tooltip_missing,'raid_enchants':phases.RAID_ENCHANTS})
print('profiles',[(f,side,len([i for i in obs['gear'] if i])) for f,v in forms.items() for side,obs in v.items()],'tooltips missing',len(tooltip_missing))
