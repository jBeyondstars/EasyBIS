from pathlib import Path
import os,sys,json,copy,ctypes,subprocess,shutil,hashlib
from concurrent.futures import ThreadPoolExecutor
p=Path(__file__).parent;t=p.parent;src=next((t/'easybis-upstream-07648faf').glob('forever-*'));study=t/'easybis-final-four-3289';d=p/'doomsaw-calibration';d.mkdir(exist_ok=True);low=getattr(subprocess,'BELOW_NORMAL_PRIORITY_CLASS',0);env={**os.environ,'CGO_ENABLED':'0','GOMAXPROCS':'3','GOARCH':'amd64'}
if os.name=='nt':ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(),0x4000)
def ld(f):return json.loads(f.read_bytes())
def save(f,v):f.write_text(json.dumps(v,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf8')
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
diag=p/'doomsaw-diagnostic';shutil.copytree(p/'runner',diag,dirs_exist_ok=True)
f=diag/'check.go';s=f.read_text();s=s.replace('type checked struct {','type checked struct {\n Procs float64 `json:"procs_16549_par_combat"`\n ProcDamage float64 `json:"degats_16549_par_combat"`')
s=s.replace('casts(out.Casts, "", metrics.Actions, float64(in.Iterations))','''casts(out.Casts, "", metrics.Actions, float64(in.Iterations))
 for _, a := range metrics.Actions { if a.Id.GetSpellId() != 16549 { continue }; for _, t := range a.Targets { out.Procs += float64(t.Hits+t.Crits+t.Misses+t.Dodges+t.Parries+t.Blocks+t.BlockedCrits+t.Glances+t.GlanceBlocks+t.Crushes)/float64(in.Iterations); out.ProcDamage += t.Damage/float64(in.Iterations) } }''')
f.write_text(s,encoding='utf8')
exe=p/'doomsaw-diagnostic.exe';subprocess.run(['go','build','-tags=with_db','-o',str(exe),*[str(diag/n) for n in ('main.go','check.go','effects.go')]],cwd=src,check=True,env=env,creationflags=low)
data=ld(src/'assets/database/db.json');baseitem=next(i for i in data['items'] if i['id']==12583)
clone={k:baseitem[k] for k in ['type','weaponType','handType','weaponSpeed','scalingOptions']};clone['id']=99012583;clone['name']='Blackhand Doomsaw, identical weapon without Fatal Wound'
def shot(x):
 side,profile=x;cfg=ld(study/'sans-jcj/form'/('cat-'+side+'.input.json')) if profile=='primary' else ld(study/'anneau-felin/form'/('cat-'+side+'.input.json'))
 player=cfg['base']['raid']['parties'][0]['players'][0];player.setdefault('database',{}).setdefault('items',[]).append(clone)
 template=cfg['jobs'][0];cfg['jobs']=[];cfg['seed']=812913;cfg['iterations']=20000
 for key,item,bonus in [('proc-free',99012583,0),('native',12583,0),('ap',99012583,40),('empty',0,0),('glaive',250619,0),('glaive-ap',250619,40),('peacemaker',18725,0),('malown',13393,0),('gyre',280059,0),('spire',274419,0),('hammer',280018,0),('bone',18420,0),('other',250615,0)]:
  j=copy.deepcopy(template);j.update(key=key,RefKey='proc-free');j['gear'][14]={'id':item,'enchant':0};j['gear'][15]={'id':0,'enchant':0};j['onUse']=list(template['onUse']);j.pop('Bonus',None)
  if bonus:j['Bonus']={'16':bonus}
  cfg['jobs'].append(j)
 tag=side+'-'+profile;ip=d/(tag+'.input.json');save(ip,cfg)
 if (d/(tag+'.json')).is_file():return tag,{r['key']:r for r in ld(d/(tag+'.json'))}
 rows=json.loads(subprocess.run([str(p/'runner.exe'),str(ip)],capture_output=True,check=True,env=env,creationflags=low).stdout)
 assert len(rows)==len(cfg['jobs']) and all(not r.get('error') for r in rows),rows
 save(d/(tag+'.json'),rows);return tag,{r['key']:r for r in rows}
if __name__=='__main__':
 with ThreadPoolExecutor(max_workers=4) as pool:out=dict(pool.map(shot,[(s,what) for what in ['primary','grade6'] for s in 'ah']))
 save(d/'summary.json',{'engine':'07648faf129cd82f99f4dd9e63b015f59f8ec811','clone':clone,'binary':sha(p/'runner.exe'),'diagnostic':sha(exe),'results':out})
 for k,v in out.items():print(k,[(x,round(v[x]['diff'],3),round(v[x]['se'],3)) for x in ['native','ap','empty','glaive','peacemaker','malown','gyre','spire','hammer','bone','other']],flush=True)
