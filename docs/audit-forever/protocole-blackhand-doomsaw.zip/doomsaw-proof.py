from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import os,sys,json,subprocess,ctypes,copy,hashlib
ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(),0x4000)
p=Path(__file__).resolve().parent;t=p.parent;prev=t/'easybis-final-four-56473177';science=t/'easybis-final-four-3289';d=p/'doomsaw';d.mkdir(exist_ok=True);low=getattr(subprocess,'BELOW_NORMAL_PRIORITY_CLASS',0);env={**os.environ,'GOMAXPROCS':'3'}
def ld(f):return json.loads(f.read_bytes())
def save(f,v):f.write_text(json.dumps(v,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf8')
tests=[]
for f in ('cat','bear'):
 for s in 'ah':
  basic=ld(science/'sans-jcj/form'/(f+'-'+s+'.input.json'));template=basic['jobs'][0]
  cfg={**basic,'iterations':20000,'seed':818527,'jobs':[]}
  primary=[250619,18420,280018,280059,250615,274419,18725] if f=='cat' else [18531,250619,280018,280059,11803,18420,18725]
  # All comparison weapons listed here have a faction-neutral source, share a two-handed slot and receive the same enchant (none).
  for i in [*primary,12583]:
   job=copy.deepcopy(template);job['key']=str(i);job['RefKey']='';job['onUse']=[];job['gear'][14]={'id':i,'enchant':0};job['gear'][15]={'id':0,'enchant':0}
   cfg['jobs'].append(job)
  ip=d/(f+'-'+s+'.input.json');save(ip,cfg);tests.append((f,s,ip,cfg))
def run(x):
 f,s,ip,cfg=x;outputs={}
 for version,engine in [('0764',p/'runner.exe'),('5647',prev/'runner.exe')]:
  z=ld(d/(f+'-'+s+'-'+version+'.json')) if (d/(f+'-'+s+'-'+version+'.json')).is_file() else json.loads(subprocess.run([str(engine),str(ip)],capture_output=True,check=True,env=env,creationflags=low).stdout)
  assert not any(r.get('error') for r in z);save(d/(f+'-'+s+'-'+version+'.json'),z);outputs[version]={r['key']:r for r in z}
 for key,r in outputs['0764'].items():
  if key=='12583':continue
  assert r==outputs['5647'][key],(f,s,key)
 trace={**cfg,'iterations':4000,'jobs':[cfg['jobs'][-1]]};tip=d/(f+'-'+s+'.check.input.json');save(tip,trace)
 tr=json.loads(subprocess.run([str(p/'doomsaw-diagnostic.exe'),'check',str(tip)],capture_output=True,check=True,env=env,creationflags=low).stdout)
 save(d/(f+'-'+s+'.check.json'),tr);cast=tr['procs_16549_par_combat'];assert cast>0,(f,s,cast)
 old=outputs['5647']['12583'];new=outputs['0764']['12583'];metric='dps' if f=='cat' else 'Threat'
 rank=sorted(outputs['0764'],key=lambda k:-outputs['0764'][k][metric])
 out={'déclenchements_16549_par_combat':cast,'dégâts_16549_par_combat':tr['degats_16549_par_combat'],'ancien_DPS':old['dps'],'nouveau_DPS':new['dps'],'gain_DPS_moyen_des_deux_exécutables':new['dps']-old['dps'],'gain_TPS_moyen_des_deux_exécutables':new['Threat']-old['Threat'],'variation_DTPS':new['Incoming']-old['Incoming'],'ordre_famille_sur_ce_témoin':rank,'indicateur':metric,'écart_DPS_direct_au_premier_testé':[new['diff'],new['se']],'graine':cfg['seed'],'source_primaire':cfg['jobs'][0]['key']}
 ref=outputs['0764'][cfg['jobs'][0]['key']]
 out['écart_TPS_direct_au_premier_testé']=[new['Threat']-ref['Threat'],new['ThreatSE']];out['écart_DTPS_direct_au_premier_testé']=[new['Incoming']-ref['Incoming'],new['IncomingSE']]
 print(f,s,cast,round(out['gain_DPS_moyen_des_deux_exécutables'],2),round(out['gain_TPS_moyen_des_deux_exécutables'],2),rank,flush=True)
 return f+'/'+s,out
with ThreadPoolExecutor(max_workers=3) as ex:out=dict(ex.map(run,tests))
save(d/'summary.json',{'new_engine':'07648faf129cd82f99f4dd9e63b015f59f8ec811','old_engine':'56473177e74075430751313fd227ba22d72ab11e','mesures':out,'source':'https://github.com/wowsims/forever/blob/07648faf129cd82f99f4dd9e63b015f59f8ec811/docs/evidence/EV-0178-proc-rate-of-blackhand-doomsaw.md'})

