from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from collections import Counter
import os,sys,ctypes,json,subprocess,copy,hashlib
ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(),0x4000)
p=Path(__file__).resolve().parent;t=p.parent;root=Path.cwd();sys.path.insert(0,str(root/'_build'));import fdb,ladders
d=p/'doomsaw-pool-standard';d.mkdir(exist_ok=True);e={**os.environ,'GOMAXPROCS':'3'};low=getattr(subprocess,'BELOW_NORMAL_PRIORITY_CLASS',0)
def ld(f):return json.loads(f.read_bytes())
def save(f,x):f.write_text(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf8')
repo=next((t/'easybis-upstream-07648faf').glob('forever-*'));native={i['id']:i for k in ('leftover_db','db') for i in ld(repo/'assets/database'/(k+'.json'))['items']};g=fdb.load('_build/cache/ForeverDB');pool=ladders.full_ladder(g,'DRUID',4,'pve','main');truth=ld(t/'easybis-soins-jcj-review/negative-missing.json');runs=[];inventory={}
def make(side,ids,tag,template,cfg,n):
 jobs=[]
 for i in ids:
  j=copy.deepcopy(template);j['key']=str(i);j['RefKey']='12583' if i!=12583 else '';j['gear'][14]={'id':i,'enchant':0};j['gear'][15]={'id':0,'enchant':0};j.pop('Bonus',None)
  if str(i) in truth:j['Bonus']=truth[str(i)]['stats']
  j['onUse']=list(dict.fromkeys([*template.get('onUse', []), *([i] if any('onUse' in effect for effect in native[i].get('itemEffects',[])) else [])]))
  jobs.append(j)
 return (tag,{**cfg,'jobs':jobs,'iterations':n,'seed':854321 if n==2000 else 867941},side)
for s in 'ah':
 cfg=ld(t/'easybis-final-four-3289/sans-jcj/form'/f'cat-{s}.input.json');template=cfg['jobs'][0];eligible={e.shown(s):e for e in ladders.visible(pool,(s,False,False,0,False,6)) if e.two_hand};complete={};missing={}
 for i,ent in eligible.items():
  it=native.get(i)
  if not it or ent.random or it.get('randomSuffixOptions'):missing[i]='ID absent ou suffixe non fixé';continue
  if it.get('classAllowlist') and 11 not in it['classAllowlist']:missing[i]='classe';continue
  if it.get('factionRestriction') and it['factionRestriction']!=('a','h').index(s)+1:missing[i]='faction';continue
  if it.get('handType')!=4:missing[i]='mode 2M non corroboré';continue
  if it.get('requiredProfession'):missing[i]='métier '+str(it['requiredProfession']);continue
  complete[i]={'rang_aux_stats':list(eligible).index(i)+1,'nom':it['name'],'points':ent.score}
 inventory[s]={'candidats':complete,'exclusions':missing};assert 12583 in complete
 ids=sorted(set(complete)-{12583})
 for a in range(0,len(ids),14):runs.append(make(s,[12583,*ids[a:a+14]],f'{s}-{a//14:02d}-2000',template,cfg,2000))
save(d/'inventory.json',inventory)
def run(q):
 name,cfg,s=q;ip=d/(name+'.input.json');outfile=d/(name+'.json');save(ip,cfg)
 if outfile.exists():return name,ld(outfile),s
 rows=json.loads(subprocess.run([str(p/'runner.exe'),str(ip)],capture_output=True,check=True,env=e,creationflags=low).stdout);assert all(not r.get('error') for r in rows) and len(rows)==len(cfg['jobs'])
 save(outfile,rows);print(name,len(rows),flush=True);return name,rows,s
def round_all(tasks):
 vals={'a':{},'h':{}}
 with ThreadPoolExecutor(max_workers=5) as ex:
  for _,rows,s in ex.map(run,tasks):
   for r in rows:vals[s][int(r['key'])]=r
 return vals
print('Périmètre',[(k,len(v['candidats']),v['exclusions']) for k,v in inventory.items()],flush=True)
first=round_all(runs);full=copy.deepcopy(first);reruns=[]
for s in 'ah':
 rows=first[s];cfg=ld(t/'easybis-final-four-3289/sans-jcj/form'/f'cat-{s}.input.json');template=cfg['jobs'][0];top=sorted(rows,key=lambda i:-rows[i]['dps']);idx=top.index(12583)+1
 print('2k, rang',s,idx,'/',len(top),'voisins',[(i,round(rows[i]['diff'],2),round(rows[i]['se'],2)) for i in top[max(idx-5,0):idx+4]],flush=True)
 ids=sorted(i for i,r in rows.items() if i!=12583 and (r['diff']>=-1.5 or abs(r['diff'])<4*r['se'] or i in top[:12]))
 for a in range(0,len(ids),11):reruns.append(make(s,[12583,*ids[a:a+11]],f'{s}-{a//11:02d}-20000',template,cfg,20000))
refined=round_all(reruns)
for s in 'ah':
 for i,r in refined[s].items():full[s][i]=r
for s,rr in full.items():
 top=sorted(rr,key=lambda i:-rr[i]['diff']);print('20k hauteurs',s,top.index(12583)+1,len(rr),[(i,round(rr[i]['diff'],2),round(rr[i]['se'],2)) for i in top[:12]],flush=True)
save(d/'summary.json',{'moteur':'07648faf129cd82f99f4dd9e63b015f59f8ec811','premier_passage':first,'précision':refined,'inventaire':inventory,'classements':{s:sorted(rr,key=lambda i:-rr[i]['diff']) for s,rr in full.items()}})

