from pathlib import Path
import json,hashlib,os,sys,subprocess,tempfile,zipfile
archive,checkout=map(Path,sys.argv[1:])
with tempfile.TemporaryDirectory(prefix='easybis-doomsaw-') as tmp:
    out=Path(tmp)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        z.extractall(out)
    sums=json.loads((out/'SHA256SUMS.json').read_bytes())
    for path,expected in sums.items():
        assert hashlib.sha256((out/path).read_bytes()).hexdigest()==expected,path
    env={**os.environ,'CGO_ENABLED':'0','GOARCH':'amd64','GOMAXPROCS':'3'}
    low=getattr(subprocess,'BELOW_NORMAL_PRIORITY_CLASS',0)
    for name in ('runner','doomsaw-diagnostic'):
        target=out/(name+'.exe')
        subprocess.run(['go','build','-tags=with_db','-o',str(target),*[str(out/name/x) for x in ('main.go','check.go','effects.go')]],cwd=checkout,env=env,creationflags=low,check=True)
        if name=='runner':
            # A physically identical weapon with its proc removed, the native proc and +40 AP.
            example=json.loads((out/'doomsaw-calibration/a-primary.input.json').read_bytes())
            example['jobs']=example['jobs'][:3]
            test=out/'ablation.json'
            test.write_text(json.dumps(example),encoding='utf8')
            got=json.loads(subprocess.run([str(target),str(test)],check=True,capture_output=True,env=env,creationflags=low).stdout)
            expected=json.loads((out/'doomsaw-calibration/a-primary.json').read_bytes())[:3]
        else:
            test=out/'doomsaw/bear-h.check.input.json'
            got=json.loads(subprocess.run([str(target),'check',str(test)],check=True,capture_output=True,env=env,creationflags=low).stdout)
            expected=json.loads((out/'doomsaw/bear-h.check.json').read_bytes())
        assert got==expected,(name,got,expected)
    print(len(sums),'fichiers vérifiés, trois comparaisons félines à 20 000 et la trace ours à 4 000 reproduites')
